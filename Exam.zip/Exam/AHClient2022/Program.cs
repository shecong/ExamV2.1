using System;
using System.Diagnostics;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using CefSharp;
using CefSharp.WinForms;
using Microsoft.Win32;
using SelfExamClient;
using SelfExamClient.Utils;
using SelfExamClient.WinForms;

namespace AHClient2022
{
	internal static class Program
	{
		[STAThread]
		private static void Main()
		{
			HCos.KeyFlag = AppConfigHelper.GetSetValueByKey("KeyFlag");
			HCos.Domain = "https://fsstu23.edu-xl.com";
			HCos.DomainOne = "https://fsstu23.edu-xl.com";
			HCos.DomainTwo = "https://fsstu23.edu-xl.com";
			HCos.errUrl = Application.StartupPath + "\\" + AppConfigHelper.GetSetValueByKey("errFile");
			HCos.SUrl = "https://fsstu23.edu-xl.com";
			HCos.isHideAll = AppConfigHelper.GetSetValueByKey("isHideAll");
			HCos.PantInterval = Convert.ToInt32(AppConfigHelper.GetSetValueByKey("Interval"));
			HCos.UpdateUrl = AppConfigHelper.GetSetValueByKey("UpdateUrl");
			HCos.UpdateLocalFile = AppConfigHelper.GetSetValueByKey("UpdataXML");
			//try
			//{
			//	Process currentProcess = Process.GetCurrentProcess();
			//	Process[] processes = Process.GetProcesses();
			//	foreach (Process process in processes)
			//	{
			//		if ((process.ProcessName == "考试平台" || process.ProcessName == "ExamClient") && process.Id != currentProcess.Id)
			//		{
			//			process.Kill();
			//		}
			//	}
			//}
			//catch
			//{
			//}
			WindowsIdentity current = WindowsIdentity.GetCurrent();
			//Application.EnableVisualStyles();
			if (new WindowsPrincipal(current).IsInRole(WindowsBuiltInRole.Administrator)||true)
			{
				try
				{
					Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
					Application.ThreadException += Application_ThreadException;
					AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
					//Application.EnableVisualStyles();
					Application.SetCompatibleTextRenderingDefault(defaultValue: false);
					_ = AppConfigHelper.GetSetValueByKey("isAutoStart") == "1";
					Cef.EnableHighDPISupport();
					CefSettings cefSettings = new CefSettings();
					cefSettings.Locale = "zh-CN";
					cefSettings.AcceptLanguageList = "zh-CN";
					cefSettings.PersistSessionCookies = false;
					cefSettings.MultiThreadedMessageLoop = true;
					cefSettings.SetOffScreenRenderingBestPerformanceArgs();
					cefSettings.CefCommandLineArgs.Add("no-proxy-server", "1");
					cefSettings.CefCommandLineArgs.Add("--js-flags", "--max_old_space_size=2048");
					cefSettings.CefCommandLineArgs.Add("enable-transparent-visuals");
					cefSettings.CefCommandLineArgs.Add("no-sandbox");
					cefSettings.CefCommandLineArgs.Add("in-process-gpu");
					cefSettings.CefCommandLineArgs.Add("--disable-software-rasterizer");
					cefSettings.CefCommandLineArgs.Add("--enable-webgl");
					cefSettings.CefCommandLineArgs.Add("--no-sandbox");
					cefSettings.CefCommandLineArgs.Add("--disable-dev-shm-usage");
					cefSettings.CefCommandLineArgs.Add("--disable-setuid-sandbox");
					cefSettings.CefCommandLineArgs.Add("--disable-gpu", "1");
					cefSettings.CefCommandLineArgs.Add("--disable-gpu-compositing", "1");
					cefSettings.CefCommandLineArgs.Add("--enable-begin-frame-scheduling", "1");
					cefSettings.CefCommandLineArgs.Add("--disable-gpu-vsync", "1");
					cefSettings.CefCommandLineArgs.Add("--disable-direct-write", "1");
					cefSettings.CefCommandLineArgs.Add("enable-media-stream", "1");
					cefSettings.CefCommandLineArgs.Add("enable-system-flash", "1");
					cefSettings.CefCommandLineArgs.Add("enable-speech-input", "1");
					Cef.Initialize(cefSettings);
					frmMain mainForm = (HCos.currentMain = new frmMain(_multiThreadedMessageLoopEnabled: true));
					//Application.EnableVisualStyles();
					Application.Run(mainForm);
				}
				catch (Exception ex)
				{
					Console.WriteLine(ex.Message);
				}
			}
			else
			{
				Process.Start(new ProcessStartInfo
				{
					FileName = Application.ExecutablePath,
					Arguments = "",
					Verb = "runas"
				});
				Application.Exit();
			}
		}

		public static void AutoStart(bool isAuto)
		{
			try
			{
				if (isAuto)
				{
					RegistryKey localMachine = Registry.LocalMachine;
					RegistryKey registryKey = localMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run");
					registryKey.SetValue("SelExamClient", Application.ExecutablePath);
					registryKey.Close();
					localMachine.Close();
				}
				else
				{
					RegistryKey localMachine2 = Registry.LocalMachine;
					RegistryKey registryKey2 = localMachine2.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run");
					registryKey2.DeleteValue("SelExamClient", throwOnMissingValue: false);
					registryKey2.Close();
					localMachine2.Close();
				}
			}
			catch (Exception)
			{
				MessageBox.Show("您需要管理员权限修改", "提示");
			}
		}

		private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
		{
			GetExceptionMsg(e.Exception, e.ToString());
		}

		private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			GetExceptionMsg(e.ExceptionObject as Exception, e.ToString());
		}

		private static string GetExceptionMsg(Exception ex, string backStr)
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("****************************异常文本****************************");
			stringBuilder.AppendLine("【出现时间】：" + DateTime.Now.ToString());
			if (ex != null)
			{
				stringBuilder.AppendLine("【异常类型】：" + ex.GetType().Name);
				stringBuilder.AppendLine("【异常信息】：" + ex.Message);
				stringBuilder.AppendLine("【堆栈调用】：" + ex.StackTrace);
			}
			else
			{
				stringBuilder.AppendLine("【未处理异常】：" + backStr);
			}
			stringBuilder.AppendLine("***************************************************************");
			return stringBuilder.ToString();
		}
	}
}
