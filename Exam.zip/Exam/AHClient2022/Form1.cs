using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using CefSharp;
using CefSharp.WinForms;
using SelfExamClient.Controls;

namespace AHClient2022
{
	public class Form1 : Form
	{
		private delegate bool EventHandler(CtrlType sig);

		private enum CtrlType
		{
			CTRL_C_EVENT = 0,
			CTRL_BREAK_EVENT = 1,
			CTRL_CLOSE_EVENT = 2,
			CTRL_LOGOFF_EVENT = 5,
			CTRL_SHUTDOWN_EVENT = 6
		}

		public ChromiumWebBrowser chromeBrowser;

		private const int WM_QUERYENDSESSION = 17;

		private const bool systemShutdown = false;

		private int isClose;

		private static EventHandler _handler;

		private IContainer components;

		private Button button1;

		private Button button2;

		public Form1()
		{
			InitializeComponent();
			_handler = (EventHandler)Delegate.Combine(_handler, new EventHandler(Handler));
			SetConsoleCtrlHandler(_handler, add: true);
		}

		public void InitializeChromium()
		{
			Cef.Initialize(new CefSettings());
			chromeBrowser = new ChromiumWebBrowser("https://www.baidu.com");
			base.Controls.Add(chromeBrowser);
			chromeBrowser.Dock = DockStyle.Fill;
		}

		protected override void WndProc(ref Message myMessage)
		{
			int msg = myMessage.Msg;
			if (msg == 17)
			{
				myMessage.Result = (IntPtr)isClose;
			}
			else
			{
				base.WndProc(ref myMessage);
			}
		}

		[DllImport("Kernel32")]
		private static extern bool SetConsoleCtrlHandler(EventHandler handler, bool add);

		private static bool Handler(CtrlType sig)
		{
			switch (sig)
			{
			case CtrlType.CTRL_C_EVENT:
				MessageBox.Show("");
				return false;
			default:
				return false;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			new PopMaskQ().Show();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			PopMask popMask = new PopMask();
			popMask.Message = "不支持多屏幕显示，请关闭其它的显示屏！";
			popMask.Show();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			button1 = new System.Windows.Forms.Button();
			button2 = new System.Windows.Forms.Button();
			SuspendLayout();
			button1.Location = new System.Drawing.Point(302, 183);
			button1.Name = "button1";
			button1.Size = new System.Drawing.Size(75, 23);
			button1.TabIndex = 0;
			button1.Text = "button1";
			button1.UseVisualStyleBackColor = true;
			button1.Click += new System.EventHandler(button1_Click);
			button2.Location = new System.Drawing.Point(306, 222);
			button2.Name = "button2";
			button2.Size = new System.Drawing.Size(75, 23);
			button2.TabIndex = 1;
			button2.Text = "button2";
			button2.UseVisualStyleBackColor = true;
			button2.Click += new System.EventHandler(button2_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(687, 506);
			base.Controls.Add(button2);
			base.Controls.Add(button1);
			base.Name = "Form1";
			Text = "Form1";
			ResumeLayout(false);
		}
	}
}
