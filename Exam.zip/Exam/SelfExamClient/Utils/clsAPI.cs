using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;
using SelfExamClient.WinForms;

namespace SelfExamClient.Utils
{
	public class clsAPI
	{
		private enum MouseEventFlag : uint
		{
			Move = 1u,
			LeftDown = 2u,
			LeftUp = 4u,
			RightDown = 8u,
			RightUp = 0x10u,
			MiddleDown = 0x20u,
			MiddleUp = 0x40u,
			XDown = 0x80u,
			XUp = 0x100u,
			Wheel = 0x800u,
			VirtualDesk = 0x4000u,
			Absolute = 0x8000u
		}

		public delegate int HookProc(int nCode, int wParam, IntPtr lParam);

		[StructLayout(LayoutKind.Sequential)]
		public class KeyBoardHookStruct
		{
			public int vkCode;

			public int scanCode;

			public int flags;

			public int time;

			public int dwExtraInfo;
		}

		[Flags]
		public enum KeyModifiers
		{
			None = 0x0,
			Alt = 0x1,
			Ctrl = 0x2,
			Shift = 0x4,
			WindowsKey = 0x8
		}

		public enum AppBarMessages
		{
			New,
			Remove,
			QueryPos,
			SetPos,
			GetState,
			GetTaskBarPos,
			Activate,
			GetAutoHideBar,
			SetAutoHideBar,
			WindowPosChanged,
			SetState
		}

		public struct APPBARDATA
		{
			public uint cbSize;

			public IntPtr hWnd;

			public uint uCallbackMessage;

			public uint uEdge;

			public Rectangle rc;

			public int lParam;
		}

		public enum AppBarStates
		{
			AutoHide = 1,
			AlwaysOnTop
		}

		private static int hHook;

		public const int WH_KEYBOARD_LL = 13;

		private static HookProc KeyBoardHookProcedure;

		[DllImport("user32.dll")]
		private static extern void mouse_event(MouseEventFlag flags, int dx, int dy, uint data, UIntPtr extraInfo);

		[DllImport("user32.dll")]
		public static extern int SetCursorPos(int x, int y);

		public static void MouseLeftClickEvent(int dx, int dy, uint data)
		{
			SetCursorPos(dx, dy);
			Thread.Sleep(2000);
			mouse_event(MouseEventFlag.LeftDown, dx, dy, data, UIntPtr.Zero);
			mouse_event(MouseEventFlag.LeftUp, dx, dy, data, UIntPtr.Zero);
		}

		[DllImport("user32 ")]
		public static extern bool LockWorkStation();

		[DllImport("user32.dll")]
		public static extern int SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hInstance, int threadId);

		[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto)]
		public static extern bool UnhookWindowsHookEx(int idHook);

		[DllImport("user32.dll")]
		public static extern int CallNextHookEx(int idHook, int nCode, int wParam, IntPtr lParam);

		[DllImport("kernel32.dll")]
		public static extern int GetCurrentThreadId();

		[DllImport("kernel32.dll")]
		public static extern IntPtr GetModuleHandle(string name);

		[DllImport("user32.dll")]
		public static extern bool GetCursorPos(ref Point lpPoint);

		[DllImport("user32.dll", SetLastError = true)]
		public static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

		[DllImport("user32.dll", SetLastError = true)]
		public static extern bool ShowWindow(IntPtr hWnd, uint nCmdShow);

		[DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
		public static extern int SetWindowPos(IntPtr hWnd, int hWndInsertAfter, int x, int y, int Width, int Height, int flags);

		public static void Hook_Start()
		{
			if (hHook == 0)
			{
				KeyBoardHookProcedure = KeyBoardHookProc;
				hHook = SetWindowsHookEx(13, KeyBoardHookProcedure, GetModuleHandle(Process.GetCurrentProcess().MainModule.ModuleName), 0);
				if (hHook == 0)
				{
					Hook_Clear();
				}
			}
		}

		public static void Hook_Clear()
		{
			bool flag = true;
			if (hHook != 0)
			{
				flag = UnhookWindowsHookEx(hHook);
				hHook = 0;
			}
			if (!flag)
			{
				throw new Exception("Hook去除失败");
			}
		}

		private static int KeyBoardHookProc(int nCode, int wParam, IntPtr lParam)
		{
			if (nCode >= 0)
			{
				KeyBoardHookStruct keyBoardHookStruct = (KeyBoardHookStruct)Marshal.PtrToStructure(lParam, typeof(KeyBoardHookStruct));
				if (keyBoardHookStruct.vkCode == 91)
				{
					return 1;
				}
				if (keyBoardHookStruct.vkCode == 92)
				{
					return 1;
				}
				string[] array = HCos.KeyFlag.Split(',');
				if (array[0] == "1" && keyBoardHookStruct.vkCode == 27 && Control.ModifierKeys == Keys.Control)
				{
					return 1;
				}
				if (array[1] == "1" && keyBoardHookStruct.vkCode == 27 && Control.ModifierKeys == Keys.Alt)
				{
					return 1;
				}
				if (array[2] == "1" && keyBoardHookStruct.vkCode == 115 && Control.ModifierKeys == Keys.Alt)
				{
					return 1;
				}
				if (array[3] == "1" && keyBoardHookStruct.vkCode == 9 && Control.ModifierKeys == Keys.Alt)
				{
					return 1;
				}
				if (array[4] == "1" && keyBoardHookStruct.vkCode == 9 && Control.ModifierKeys == (Keys.Control | Keys.Alt))
				{
					return 1;
				}
				if (array[5] == "1" && keyBoardHookStruct.vkCode == 32 && Control.ModifierKeys == Keys.Alt)
				{
					return 1;
				}
				if (array[6] == "1" && keyBoardHookStruct.vkCode == 241)
				{
					return 1;
				}
				if (array[7] == "1" && keyBoardHookStruct.vkCode == 65 && Control.ModifierKeys == Keys.Alt)
				{
					return 1;
				}
				if (array[8] == "1" && keyBoardHookStruct.vkCode == 65 && Control.ModifierKeys == Keys.Control)
				{
					return 1;
				}
				if (array[9] == "1" && keyBoardHookStruct.vkCode == 65 && Control.ModifierKeys == (Keys.Control | Keys.Alt))
				{
					return 1;
				}
				if (array[10] == "1" && keyBoardHookStruct.vkCode == 90 && Control.ModifierKeys == (Keys.Control | Keys.Alt))
				{
					return 1;
				}
				if (keyBoardHookStruct.vkCode == 48 && Control.ModifierKeys == Keys.Control)
				{
					if (HCos.IsOpenOnline)
					{
						return 1;
					}
					if (HCos.IsOpen || HCos.IsExamOpen)
					{
						HCos.IsOpenOnline = true;
						MessageBox.Show("请关闭其它窗口，返回首页！");
						HCos.IsOpenOnline = false;
						return 1;
					}
					new frmOnline().Show();
				}
				if (keyBoardHookStruct.vkCode == 55 && Control.ModifierKeys == (Keys.Control | Keys.Alt))
				{
					if (HCos.IsOpen)
					{
						return 1;
					}
					new frmCJPass().ShowDialog();
				}
				if ((keyBoardHookStruct.vkCode == 91 && keyBoardHookStruct.vkCode == 76) || (keyBoardHookStruct.vkCode == 92 && keyBoardHookStruct.vkCode == 76))
				{
					return 1;
				}
			}
			return CallNextHookEx(hHook, nCode, wParam, lParam);
		}

		public static void TaskMgrLocking(bool bLock)
		{
			if (bLock)
			{
				Process process = new Process();
				process.StartInfo.WorkingDirectory = Environment.GetFolderPath(Environment.SpecialFolder.System);
				process.StartInfo.FileName = "taskmgr.exe";
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
				process.Start();
				return;
			}
			Process[] processes = Process.GetProcesses();
			foreach (Process process2 in processes)
			{
				try
				{
					if (process2.ProcessName.ToLower().Trim() == "taskmgr")
					{
						process2.Kill();
						Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", writable: true).SetValue("DisableTaskmgr", "0");
						Registry.CurrentUser.DeleteSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
					}
				}
				catch
				{
					return;
				}
			}
		}

		public static Point GetCursorPos()
		{
			Point lpPoint = default(Point);
			GetCursorPos(ref lpPoint);
			return lpPoint;
		}

		public static void HideTask(bool isHide)
		{
			try
			{
				IntPtr hWnd = FindWindowEx(IntPtr.Zero, IntPtr.Zero, "Shell_TrayWnd", null);
				IntPtr hWnd2 = FindWindowEx(IntPtr.Zero, IntPtr.Zero, "Button", null);
				if (isHide)
				{
					ShowWindow(hWnd, 0u);
					ShowWindow(hWnd2, 0u);
				}
				else
				{
					ShowWindow(hWnd, 1u);
					ShowWindow(hWnd2, 1u);
				}
				if (GetTaskbarState() == AppBarStates.AlwaysOnTop && isHide)
				{
					SetTaskbarState(AppBarStates.AutoHide);
				}
			}
			catch
			{
			}
		}

		[DllImport("user32.dll", SetLastError = true)]
		public static extern bool RegisterHotKey(IntPtr hWnd, int id, KeyModifiers fsModifiers, Keys vk);

		[DllImport("user32.dll", SetLastError = true)]
		public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

		public static bool RegHotKey(IntPtr hwnd, int hotKeyId, KeyModifiers keyModifiers, Keys key)
		{
			bool result = true;
			if (!RegisterHotKey(hwnd, hotKeyId, keyModifiers, key))
			{
				Marshal.GetLastWin32Error();
				result = false;
			}
			return result;
		}

		public static void UnRegHotKey(IntPtr hwnd, int hotKeyId)
		{
			UnregisterHotKey(hwnd, hotKeyId);
		}

		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr FindWindow(string strClassName, string strWindowName);

		[DllImport("shell32.dll")]
		public static extern uint SHAppBarMessage(uint dwMessage, ref APPBARDATA pData);

		public static void SetTaskbarState(AppBarStates option)
		{
			APPBARDATA pData = default(APPBARDATA);
			pData.cbSize = (uint)Marshal.SizeOf(pData);
			pData.hWnd = FindWindow("System_TrayWnd", null);
			pData.lParam = (int)option;
			SHAppBarMessage(10u, ref pData);
		}

		public static AppBarStates GetTaskbarState()
		{
			APPBARDATA pData = default(APPBARDATA);
			pData.cbSize = (uint)Marshal.SizeOf(pData);
			pData.hWnd = FindWindow("System_TrayWnd", null);
			return (AppBarStates)SHAppBarMessage(4u, ref pData);
		}

		public static void StopProcess(string processName)
		{
			try
			{
				Console.WriteLine(processName);
				Process[] processesByName = Process.GetProcessesByName(processName);
				Console.WriteLine(processesByName.Length);
				Process[] array = processesByName;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].Kill();
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}
