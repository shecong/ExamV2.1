namespace SelfExamClient.Utils
{
	public class Integrate
	{
		public void sendQrCode(string code)
		{
			Common.WriteLog(code);
			HCos.Base64Qrode = code;
		}

		public void sendLogicIdAndUid(string logicId, string examUID, string token)
		{
			HCos.examLogicId = logicId;
			HCos.examUID = examUID;
			HCos.Token = token;
		}

		public void Show()
		{
			HCos.currentMain.ShowContorl();
		}
	}
}
