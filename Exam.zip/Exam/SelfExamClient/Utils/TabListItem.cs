namespace SelfExamClient.Utils
{
	public class TabListItem
	{
		public string searchValue { get; set; }

		public string createBy { get; set; }

		public string createTime { get; set; }

		public string updateBy { get; set; }

		public string updateTime { get; set; }

		public string remark { get; set; }

		public int id { get; set; }

		public int userId { get; set; }

		public string userName { get; set; }

		public string userExamId { get; set; }

		public string examLogicId { get; set; }

		public string examCode { get; set; }

		public string examUnit { get; set; }

		public string courseCode { get; set; }

		public string roomCode { get; set; }

		public string siteCode { get; set; }

		public string tabType { get; set; }

		public int deptId { get; set; }

		public int adminUserId { get; set; }

		public string siteName { get; set; }

		public string subjectName { get; set; }

		public string idCardNo { get; set; }

		public string ids { get; set; }

		public string key { get; set; }

		public string value { get; set; }
	}
}
