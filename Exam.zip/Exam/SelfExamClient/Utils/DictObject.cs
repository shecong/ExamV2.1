using System.Collections.Generic;

namespace SelfExamClient.Utils
{
	public class DictObject
	{
		public string msg { get; set; }

		public int code { get; set; }

		public List<DictItem> data { get; set; }

		public string success { get; set; }

		public string message { get; set; }
	}
}
