namespace SelfExamClient.Utils
{
	public class CallBackJsInvoker
	{
		public static event CallBackJsDelegate CallBackJsEvent;

		public static void ExcuteJsAsync(string method, params object[] parmeters)
		{
			CallBackJsInvoker.CallBackJsEvent?.Invoke(method, parmeters);
		}
	}
}
