namespace SelfExamClient.Utils
{
	public class DictItem
	{
		public string searchValue { get; set; }

		public string createBy { get; set; }

		public string createTime { get; set; }

		public string updateBy { get; set; }

		public string updateTime { get; set; }

		public string remark { get; set; }

		public int dictCode { get; set; }

		public int dictSort { get; set; }

		public string dictLabel { get; set; }

		public string dictValue { get; set; }

		public string dictType { get; set; }

		public string cssClass { get; set; }

		public string listClass { get; set; }

		public string isDefault { get; set; }

		public string status { get; set; }

		public string @default { get; set; }
	}
}
