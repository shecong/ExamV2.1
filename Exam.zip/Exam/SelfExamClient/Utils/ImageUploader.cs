using System;
using System.IO;
using System.Net;

namespace SelfExamClient.Utils
{
	public class ImageUploader
	{
		public static void UpLoadFile(string fileNamePath, string serverUri)
		{
			UpLoadFile(fileNamePath, serverUri, IsAutoRename: false);
		}

		public static void UpLoadFile(string fileNamePath, string uriString, bool IsAutoRename)
		{
			string text;
			string text2 = (text = fileNamePath.Substring(fileNamePath.LastIndexOf("\\") + 1));
			if (IsAutoRename)
			{
				text = DateTime.Now.ToString("yyMMddhhmmss") + DateTime.Now.Millisecond + fileNamePath.Substring(fileNamePath.LastIndexOf("."));
			}
			text2.Substring(text2.LastIndexOf(".") + 1);
			if (!uriString.EndsWith("/"))
			{
				uriString += "/";
			}
			if (!Directory.Exists(uriString))
			{
				Directory.CreateDirectory(uriString);
			}
			uriString += text;
			WebClient obj = new WebClient
			{
				Credentials = CredentialCache.DefaultCredentials
			};
			FileStream fileStream = new FileStream(fileNamePath, FileMode.Open, FileAccess.Read);
			byte[] array = new BinaryReader(fileStream).ReadBytes((int)fileStream.Length);
			Stream stream = obj.OpenWrite(uriString, "PUT");
			try
			{
				if (stream.CanWrite)
				{
					stream.Write(array, 0, array.Length);
					stream.Close();
					fileStream.Dispose();
				}
				else
				{
					stream.Close();
					fileStream.Dispose();
				}
			}
			catch (Exception ex)
			{
				stream.Close();
				fileStream.Dispose();
				throw ex;
			}
			finally
			{
				stream.Close();
				fileStream.Dispose();
			}
		}
	}
}
