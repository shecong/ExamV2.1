namespace SelfExamClient.Utils
{
	public class InputMethod
	{
		public void Open()
		{
			if (HCos.currentOpen != null)
			{
				HCos.currentOpen.SetInputMethod();
			}
		}
	}
}
