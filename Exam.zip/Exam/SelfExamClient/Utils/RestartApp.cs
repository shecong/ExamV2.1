namespace SelfExamClient.Utils
{
	public class RestartApp
	{
		public void Restart()
		{
			try
			{
				Common.Restart();
			}
			catch
			{
			}
		}
	}
}
