namespace SelfExamClient.Utils
{
	public class Calc
	{
		public void Open()
		{
			if (!HCos.IsCalcOpen)
			{
				_ = HCos.IsWritingOpen;
			}
		}
	}
}
