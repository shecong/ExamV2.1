namespace SelfExamClient.Utils
{
	public delegate void CallBackJsDelegate(string method, params object[] parmeters);
}
