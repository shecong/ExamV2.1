namespace SelfExamClient.Utils
{
	public class ServerMessageObject
	{
		public string msg { get; set; }

		public int code { get; set; }

		public ServerMessage data { get; set; }

		public string success { get; set; }

		public string message { get; set; }
	}
}
