namespace SelfExamClient.Utils
{
	public class UploadFileReponse
	{
	}
}
