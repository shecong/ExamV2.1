namespace SelfExamClient.Utils
{
	public class AutoUpdate
	{
		public string version { get; set; }

		public string url { get; set; }

		public string start { get; set; }

		public string note { get; set; }
	}
}
