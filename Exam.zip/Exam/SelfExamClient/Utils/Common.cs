using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;

namespace SelfExamClient.Utils
{
	public class Common
	{
		public enum ProcessAccessFlags
		{
			PROCESS_TERMINATE = 1,
			PROCESS_CREATE_THREAD = 2,
			PROCESS_VM_OPERATION = 8,
			PROCESS_VM_READ = 0x10,
			PROCESS_VM_WRITE = 0x20,
			PROCESS_DUP_HANDLE = 0x40,
			PROCESS_CREATE_PROCESS = 0x80,
			PROCESS_SET_QUOTA = 0x100,
			PROCESS_SET_INFORMATION = 0x200,
			PROCESS_QUERY_INFORMATION = 0x400,
			PROCESS_SUSPEND_RESUME = 0x800,
			PROCESS_QUERY_LIMITED_INFORMATION = 0x1000,
			SYNCHRONIZE = 0x100000,
			DELETE = 0x10000,
			READ_CONTROL = 0x20000,
			WRITE_DAC = 0x40000,
			WRITE_OWNER = 0x80000,
			STANDARD_RIGHTS_REQUIRED = 983040,
			PROCESS_ALL_ACCESS = 0x1FFFFF
		}

		public static int flags;

		private const int LanNetworkConnectedFlag = 1;

		public static bool IsConnected
		{
			get
			{
				bool flag = true;
				try
				{
					HttpWebRequest obj = (HttpWebRequest)WebRequest.Create(HCos.Domain);
					obj.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko";
					obj.Method = "GET";
					HttpWebResponse obj2 = (HttpWebResponse)obj.GetResponse();
					flag = ((obj2.StatusCode == HttpStatusCode.OK) ? true : false);
					obj2.Close();
					return flag;
				}
				catch (WebException)
				{
					return false;
				}
				catch (Exception)
				{
					return false;
				}
			}
		}

		public static bool UploadImageToServer(string filePath, out string tempName, out string fileName, out string errMsg, string url)
		{
			errMsg = "";
			tempName = "";
			fileName = "";
			return false;
		}

		public static void WriteLog(string strLog)
		{
			try
			{
				string text = Application.StartupPath + "\\";
				string text2 = "jk" + DateTime.Now.ToString("yyyy-MM-dd") + ".log";
				text2 = text + "\\" + text2;
				if (!Directory.Exists(text))
				{
					Directory.CreateDirectory(text);
				}
				FileStream fileStream = ((!File.Exists(text2)) ? new FileStream(text2, FileMode.Create, FileAccess.Write) : new FileStream(text2, FileMode.Append, FileAccess.Write));
				StreamWriter streamWriter = new StreamWriter(fileStream);
				streamWriter.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss ffff") + "   ---   " + strLog);
				streamWriter.Close();
				fileStream.Close();
			}
			catch
			{
			}
		}

		[DllImport("sensapi.dll", SetLastError = true)]
		private static extern bool IsNetworkAlive(out int connectionDescription);

		[DllImport("winInet.dll")]
		private static extern bool InternetGetConnectedState(ref IntPtr dwFlag, int dwReserved);

		public static void Restart()
		{
			Thread thread = new Thread(run);
			object executablePath = Application.ExecutablePath;
			Thread.Sleep(1000);
			thread.Start(executablePath);
		}

		private static void run(object obj)
		{
			Process process = new Process();
			process.StartInfo.FileName = obj.ToString();
			process.Start();
		}

		public static Image Base64ToIamge(string base64)
		{
			base64 = base64.Replace("data:image/png;base64,", "").Replace("data:image/jgp;base64,", "").Replace("data:image/jpg;base64,", "")
				.Replace("data:image/jpeg;base64,", "");
			base64 = base64.Replace("data:image/PNG;base64,", "");
			return Image.FromStream(new MemoryStream(Convert.FromBase64String(base64)));
		}

		public static void MoveControlToCenter(Control ctrl, Control parent)
		{
			int x = (int)(0.5 * (double)(parent.Width - ctrl.Width));
			int y = ctrl.Location.Y;
			ctrl.Location = new Point(x, y);
		}

		public static string GetWebRequest(string Url, string postDataStr)
		{
			HttpWebRequest obj = (HttpWebRequest)WebRequest.Create(Url + ((postDataStr == "") ? "" : "?") + postDataStr);
			obj.Method = "GET";
			obj.ContentType = "text/html;charset=UTF-8";
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
			Stream responseStream = ((HttpWebResponse)obj.GetResponse()).GetResponseStream();
			StreamReader streamReader = new StreamReader(responseStream, Encoding.GetEncoding("utf-8"));
			string result = streamReader.ReadToEnd();
			streamReader.Close();
			responseStream.Close();
			return result;
		}

		public static string GetKeyValue(string filename, string key)
		{
			string result = "";
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load(filename);
			XmlNodeList elementsByTagName = xmlDocument.GetElementsByTagName("add");
			for (int i = 0; i < elementsByTagName.Count; i++)
			{
				if (elementsByTagName[i].Attributes["key"].Value == key)
				{
					result = elementsByTagName[i].Attributes["value"].Value;
					break;
				}
			}
			return result;
		}

		[DllImport("user32.dll")]
		private static extern uint SetWindowDisplayAffinity(IntPtr hwnd, uint dwAffinity);

		public static void Protect(IntPtr handle)
		{
			SetWindowDisplayAffinity(handle, 1u);
		}

		[DllImport("user32.dll")]
		public static extern IntPtr FindWindow(string className, string captionName);

		[DllImport("user32.dll")]
		public static extern bool ShowWindow(IntPtr hwnd, uint nCmdShow);

		[DllImport("user32.dll")]
		public static extern bool ShowCursor(bool bShow);

		[DllImport("kernel32.dll")]
		private static extern bool QueryFullProcessImageName(IntPtr hprocess, int dwFlags, StringBuilder lpExeName, out int size);

		[DllImport("kernel32.dll")]
		private static extern IntPtr OpenProcess(ProcessAccessFlags dwDesiredAccess, bool bInheritHandle, int dwProcessId);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool CloseHandle(IntPtr hHandle);

		public static string GetExecutablePathAboveVista(int ProcessId)
		{
			StringBuilder stringBuilder = new StringBuilder(1024);
			IntPtr intPtr = OpenProcess(ProcessAccessFlags.PROCESS_QUERY_LIMITED_INFORMATION, bInheritHandle: false, ProcessId);
			if (intPtr != IntPtr.Zero)
			{
				try
				{
					int size = stringBuilder.Capacity;
					if (QueryFullProcessImageName(intPtr, 0, stringBuilder, out size))
					{
						return stringBuilder.ToString();
					}
				}
				finally
				{
					CloseHandle(intPtr);
				}
			}
			return "";
		}
	}
}
