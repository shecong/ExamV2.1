using CefSharp;

namespace SelfExamClient.Utils
{
	public static class CommonEntity
	{
		public static IBrowser currentBrowser;
	}
}
