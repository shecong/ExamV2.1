namespace SelfExamClient.Utils
{
	public class ObjectMessage
	{
		public string msg { get; set; }

		public int code { get; set; }

		public string data { get; set; }

		public string success { get; set; }

		public string message { get; set; }
	}
}
