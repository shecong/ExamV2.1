using System.Collections.Generic;

namespace SelfExamClient.Utils
{
	public class ServerMessage
	{
		public List<TabListItem> tabList { get; set; }

		public string sideStatus { get; set; }

		public string submitStatus { get; set; }

		public List<MsgListItem> msgList { get; set; }
	}
}
