namespace SelfExamClient.Utils
{
	public class ObjectList
	{
	}
}
