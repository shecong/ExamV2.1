namespace SelfExamClient.Utils
{
	public class LogHelper
	{
	}
}
