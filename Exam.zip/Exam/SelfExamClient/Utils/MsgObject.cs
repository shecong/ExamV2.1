namespace SelfExamClient.Utils
{
	public class MsgObject
	{
		public string MsgType { get; set; } = "";


		public string Message { get; set; } = "";

	}
}
