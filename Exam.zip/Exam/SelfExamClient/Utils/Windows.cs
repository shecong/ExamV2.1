using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Text;

namespace SelfExamClient.Utils
{
	public class Windows : IEnumerable, IEnumerator
	{
		public delegate bool EnumWindowsProc(int hWnd, int lParam);

		private int m_Position = -1;

		private ArrayList wndArray = new ArrayList();

		private bool m_invisible;

		private bool m_notitle;

		public object Current => wndArray[m_Position];

		[DllImport("user32.dll", CharSet = CharSet.Ansi)]
		public static extern int SetWindowText(int hwnd, string lpString);

		[DllImport("user32.dll")]
		private static extern int GetWindowText(int hWnd, StringBuilder title, int size);

		[DllImport("user32.dll")]
		private static extern int GetWindowModuleFileName(int hWnd, StringBuilder title, int size);

		[DllImport("user32.dll")]
		private static extern int EnumWindows(EnumWindowsProc ewp, int lParam);

		[DllImport("user32.dll")]
		private static extern bool IsWindowVisible(int hWnd);

		public Windows(bool Invisible, bool Untitled)
		{
			m_invisible = Invisible;
			m_notitle = Untitled;
			EnumWindows(EvalWindow, 0);
		}

		public Windows()
		{
			EnumWindows(EvalWindow, 0);
		}

		private bool EvalWindow(int hWnd, int lParam)
		{
			if (!m_invisible && !IsWindowVisible(hWnd))
			{
				return true;
			}
			StringBuilder stringBuilder = new StringBuilder(256);
			StringBuilder stringBuilder2 = new StringBuilder(256);
			GetWindowModuleFileName(hWnd, stringBuilder2, 256);
			GetWindowText(hWnd, stringBuilder, 256);
			if (!m_notitle && stringBuilder.Length == 0)
			{
				return true;
			}
			wndArray.Add(new Window(stringBuilder.ToString(), (IntPtr)hWnd, stringBuilder2.ToString()));
			return true;
		}

		public IEnumerator GetEnumerator()
		{
			return this;
		}

		public bool MoveNext()
		{
			m_Position++;
			if (m_Position < wndArray.Count)
			{
				return true;
			}
			return false;
		}

		public void Reset()
		{
			m_Position = -1;
		}
	}
}
