using System;
using System.IO;
using System.Net;
using System.Text;

namespace SelfExamClient.Utils
{
	public class HttpAsyncRequestHelper
	{
		public delegate void AsyRequetCallback(object asyObj, string respStr, int statusCode, WebException webEx);

		public class AsyResultTag
		{
			public object obj { get; set; }

			public HttpWebRequest req { get; set; }

			public AsyRequetCallback callback { get; set; }
		}

		public static void HttpAsyncRequest(string url, string reqMethod, AsyRequetCallback callback, object ob = null, string postData = "", string contentType = "application/x-www-form-urlencoded")
		{
			Stream stream = null;
			try
			{
				GC.Collect();
				HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
				httpWebRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)";
				httpWebRequest.ContentType = contentType;
				httpWebRequest.Method = reqMethod;
				if (reqMethod.ToUpper() == "POST")
				{
					byte[] bytes = Encoding.UTF8.GetBytes(postData);
					httpWebRequest.ContentLength = bytes.Length;
					stream = httpWebRequest.GetRequestStream();
					stream.Write(bytes, 0, bytes.Length);
				}
				httpWebRequest.BeginGetResponse(HttpCallback, new AsyResultTag
				{
					obj = ob,
					callback = callback,
					req = httpWebRequest
				});
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				stream?.Close();
			}
		}

		private static void HttpCallback(IAsyncResult asynchronousResult)
		{
			int statusCode = 0;
			string respStr = "";
			AsyResultTag asyResultTag = new AsyResultTag();
			WebException webEx = null;
			try
			{
				asyResultTag = asynchronousResult.AsyncState as AsyResultTag;
				HttpWebRequest req = asyResultTag.req;
				req.KeepAlive = false;
				req.ProtocolVersion = HttpVersion.Version10;
				ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
				ServicePointManager.DefaultConnectionLimit = 500;
				HttpWebResponse obj = req.EndGetResponse(asynchronousResult) as HttpWebResponse;
				Stream responseStream = obj.GetResponseStream();
				StreamReader streamReader = new StreamReader(responseStream, Encoding.GetEncoding("utf-8"));
				respStr = streamReader.ReadToEnd();
				streamReader.Close();
				responseStream.Close();
				statusCode = (int)obj.StatusCode;
			}
			catch (WebException ex)
			{
				if ((HttpWebResponse)ex.Response != null)
				{
					statusCode = (int)((HttpWebResponse)ex.Response).StatusCode;
				}
				webEx = ex;
			}
			asyResultTag.callback(asyResultTag.obj, respStr, statusCode, webEx);
		}
	}
}
