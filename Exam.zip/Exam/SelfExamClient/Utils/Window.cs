using System;
using System.Runtime.InteropServices;

namespace SelfExamClient.Utils
{
	public class Window
	{
		private const int SW_HIDE = 0;

		private const int SW_SHOWNORMAL = 1;

		private const int SW_SHOWMINIMIZED = 2;

		private const int SW_SHOWMAXIMIZED = 3;

		private const int SW_SHOWNOACTIVATE = 4;

		private const int SW_RESTORE = 9;

		private const int SW_SHOWDEFAULT = 10;

		private IntPtr m_hWnd;

		private string m_Title;

		private bool m_Visible = true;

		private string m_Process;

		private bool m_WasMax;

		public IntPtr hWnd => m_hWnd;

		public string Title => m_Title;

		public string Process => m_Process;

		public bool Visible
		{
			get
			{
				return m_Visible;
			}
			set
			{
				if (value)
				{
					if (m_WasMax)
					{
						if (ShowWindowAsync(m_hWnd, 3))
						{
							m_Visible = true;
						}
					}
					else if (ShowWindowAsync(m_hWnd, 1))
					{
						m_Visible = true;
					}
				}
				if (!value)
				{
					m_WasMax = IsZoomed(m_hWnd);
					if (ShowWindowAsync(m_hWnd, 0))
					{
						m_Visible = false;
					}
				}
			}
		}

		[DllImport("user32.dll")]
		private static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);

		[DllImport("user32.dll")]
		private static extern bool SetForegroundWindow(IntPtr hWnd);

		[DllImport("user32.dll")]
		private static extern bool IsIconic(IntPtr hWnd);

		[DllImport("user32.dll")]
		private static extern bool IsZoomed(IntPtr hWnd);

		[DllImport("user32.dll")]
		private static extern IntPtr GetForegroundWindow();

		[DllImport("user32.dll")]
		private static extern IntPtr GetWindowThreadProcessId(IntPtr hWnd, IntPtr ProcessId);

		[DllImport("user32.dll")]
		private static extern IntPtr AttachThreadInput(IntPtr idAttach, IntPtr idAttachTo, int fAttach);

		public Window(string Title, IntPtr hWnd, string Process)
		{
			m_Title = Title;
			m_hWnd = hWnd;
			m_Process = Process;
		}

		public override string ToString()
		{
			if (m_Title.Length > 0)
			{
				return m_Title;
			}
			return m_Process;
		}

		public void Activate()
		{
			if (!(m_hWnd == GetForegroundWindow()))
			{
				IntPtr windowThreadProcessId = GetWindowThreadProcessId(GetForegroundWindow(), IntPtr.Zero);
				IntPtr windowThreadProcessId2 = GetWindowThreadProcessId(m_hWnd, IntPtr.Zero);
				if (windowThreadProcessId != windowThreadProcessId2)
				{
					AttachThreadInput(windowThreadProcessId, windowThreadProcessId2, 1);
					SetForegroundWindow(m_hWnd);
					AttachThreadInput(windowThreadProcessId, windowThreadProcessId2, 0);
				}
				else
				{
					SetForegroundWindow(m_hWnd);
				}
				if (IsIconic(m_hWnd))
				{
					ShowWindowAsync(m_hWnd, 9);
				}
				else
				{
					ShowWindowAsync(m_hWnd, 1);
				}
			}
		}
	}
}
