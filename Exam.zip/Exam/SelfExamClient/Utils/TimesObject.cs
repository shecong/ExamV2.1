namespace SelfExamClient.Utils
{
	public class TimesObject
	{
		public string msg { get; set; }

		public int code { get; set; }

		public long data { get; set; }

		public string success { get; set; }

		public string message { get; set; }
	}
}
