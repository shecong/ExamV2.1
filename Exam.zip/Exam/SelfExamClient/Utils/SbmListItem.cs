namespace SelfExamClient.Utils
{
	public class SbmListItem
	{
		public string searchValue { get; set; }

		public string createBy { get; set; }

		public string createTime { get; set; }

		public string updateBy { get; set; }

		public string updateTime { get; set; }

		public string remark { get; set; }

		public int id { get; set; }

		public int userId { get; set; }

		public string userName { get; set; }

		public string userExamId { get; set; }

		public string examLogicId { get; set; }

		public string examCode { get; set; }

		public string courseCode { get; set; }

		public string courseName { get; set; }

		public string examUnit { get; set; }

		public string roomCode { get; set; }

		public string siteCode { get; set; }

		public string msgContent { get; set; }

		public int operUserId { get; set; }

		public string operUserName { get; set; }

		public string msgType { get; set; }

		public string status { get; set; }

		public string updateDate { get; set; }
	}
}
