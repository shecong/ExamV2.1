using System;
using System.Drawing;
using System.Windows.Forms;

namespace SelfExamClient.Utils
{
	public class Cls_MoveControl
	{
		public enum MoveDirection
		{
			Any,
			Horizontal,
			Vertical
		}

		private int int_FrmWidth = 200;

		private int int_FrmHeight = 200;

		public int Int_FrmWidth
		{
			get
			{
				return int_FrmWidth;
			}
			set
			{
				int_FrmWidth = value;
			}
		}

		public int Int_FrmHeight
		{
			get
			{
				return int_FrmHeight;
			}
			set
			{
				int_FrmHeight = value;
			}
		}

		public Cls_MoveControl(int width, int height)
		{
			int_FrmWidth = width;
			int_FrmHeight = height;
		}

		public Cls_MoveControl(Control frm)
		{
			Cls_MoveControl cls_MoveControl = this;
			int_FrmWidth = frm.ClientRectangle.Width;
			int_FrmHeight = frm.ClientRectangle.Height;
			frm.Resize += delegate
			{
				cls_MoveControl.int_FrmWidth = frm.ClientRectangle.Width;
				cls_MoveControl.int_FrmHeight = frm.ClientRectangle.Height;
			};
		}

		public void ApplyMove(Control control)
		{
			ApplyMove(control, MoveDirection.Any);
		}

		public void ApplyMove(Control control, MoveDirection moveDirection)
		{
			ApplyMove(control, control, moveDirection);
		}

		public void ApplyMove(Control control, Control container, MoveDirection moveDirection)
		{
			bool isDrag = false;
			Point dragStartPoint = Point.Empty;
			control.MouseDown += delegate(object sender, MouseEventArgs e)
			{
				isDrag = true;
				dragStartPoint = new Point(e.X, e.Y);
				control.Cursor = Cursors.SizeAll;
				control.Capture = true;
			};
			control.MouseUp += delegate
			{
				isDrag = false;
				control.Cursor = Cursors.Default;
				control.Capture = false;
			};
			control.MouseMove += delegate(object sender, MouseEventArgs e)
			{
				if (isDrag)
				{
					if (moveDirection != MoveDirection.Vertical)
					{
						int val = container.Left + e.X - dragStartPoint.X;
						container.Left = GetMiddleValue(val, container.Width, int_FrmWidth);
					}
					if (moveDirection != MoveDirection.Horizontal)
					{
						int val2 = container.Top + e.Y - dragStartPoint.Y;
						container.Top = GetMiddleValue(val2, container.Height, int_FrmHeight);
					}
				}
			};
		}

		private int GetMiddleValue(int val, int containerWOH, int FrmWOH)
		{
			int num = 0;
			int num2 = FrmWOH - containerWOH;
			if (val < num)
			{
				val = num;
			}
			if (val > num2)
			{
				val = num2;
			}
			Console.WriteLine(val);
			return val;
		}
	}
}
