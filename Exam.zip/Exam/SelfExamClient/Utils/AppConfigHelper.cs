using System.Configuration;

namespace SelfExamClient.Utils
{
	public class AppConfigHelper
	{
		public static string GetSetValueByKey(string key)
		{
			bool flag = false;
			foreach (string key2 in ConfigurationManager.AppSettings.Keys)
			{
				if (key2 == key)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				return null;
			}
			return ConfigurationManager.AppSettings[key].ToString();
		}
	}
}
