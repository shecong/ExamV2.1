using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using SelfExamClient.Properties;
using SelfExamClient.Utils;

namespace SelfExamClient.Controls
{
	public class PopContent : Form
	{
		private string _Message;

		private IContainer components;

		private Panel panel1;

		private Label label1;

		private PictureBox pictureBox1;

		private PictureBox picClose;

		private PictureBox pictureBox2;

		private Label lblMessage;

		private PictureBox pictureBox4;

		public string Message
		{
			set
			{
				ShowMessage(value);
			}
		}

		public PopContent()
		{
			InitializeComponent();
		}

		private void ShowMessage(string message)
		{
			if (message == "")
			{
				return;
			}
			if (base.InvokeRequired)
			{
				Invoke((MethodInvoker)delegate
				{
					ShowMessage(message);
				});
			}
			else
			{
				lblMessage.Text = message;
			}
		}

		private void PopContent_Load(object sender, EventArgs e)
		{
			Common.MoveControlToCenter(picClose, this);
		}

		private void PopContent_FormClosed(object sender, FormClosedEventArgs e)
		{
			Application.OpenForms["PopMask"].Close();
		}

		private void picClose_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void PopContent_Resize(object sender, EventArgs e)
		{
			SetWindowRegion();
		}

		public void SetWindowRegion()
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			Rectangle rect = new Rectangle(0, 0, base.Width, base.Height);
			graphicsPath = GetRoundedRectPath(rect, 10);
			base.Region = new Region(graphicsPath);
		}

		private GraphicsPath GetRoundedRectPath(Rectangle rect, int radius)
		{
			Rectangle rect2 = new Rectangle(rect.Location, new Size(radius, radius));
			GraphicsPath graphicsPath = new GraphicsPath();
			graphicsPath.AddArc(rect2, 180f, 90f);
			rect2.X = rect.Right - radius;
			graphicsPath.AddArc(rect2, 270f, 90f);
			rect2.Y = rect.Bottom - radius;
			graphicsPath.AddArc(rect2, 0f, 90f);
			rect2.X = rect.Left;
			graphicsPath.AddArc(rect2, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		private void PopContent_Paint(object sender, PaintEventArgs e)
		{
			Rectangle clientRectangle = base.ClientRectangle;
			Graphics graphics = e.Graphics;
			Pen pen = new Pen(Color.WhiteSmoke);
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics.CompositingQuality = CompositingQuality.HighQuality;
			graphics.DrawLine(pen, 0, 0, 0, clientRectangle.Height - 1);
			graphics.DrawLine(pen, 0, clientRectangle.Height - 1, clientRectangle.Width - 1, clientRectangle.Height - 1);
			graphics.DrawLine(pen, clientRectangle.Width - 1, clientRectangle.Height - 1, clientRectangle.Width - 1, 0);
			graphics.DrawLine(pen, clientRectangle.Width - 1, 0, 0, 0);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			panel1 = new System.Windows.Forms.Panel();
			label1 = new System.Windows.Forms.Label();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			lblMessage = new System.Windows.Forms.Label();
			picClose = new System.Windows.Forms.PictureBox();
			pictureBox2 = new System.Windows.Forms.PictureBox();
			pictureBox4 = new System.Windows.Forms.PictureBox();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			((System.ComponentModel.ISupportInitialize)picClose).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
			SuspendLayout();
			panel1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			panel1.BackColor = System.Drawing.Color.WhiteSmoke;
			panel1.Controls.Add(label1);
			panel1.Controls.Add(pictureBox1);
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(480, 48);
			panel1.TabIndex = 5;
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font("微软雅黑", 12f, System.Drawing.FontStyle.Bold);
			label1.Location = new System.Drawing.Point(18, 12);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(74, 22);
			label1.TabIndex = 1;
			label1.Text = "警告提示";
			pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
			pictureBox1.Location = new System.Drawing.Point(452, 9);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(20, 20);
			pictureBox1.TabIndex = 0;
			pictureBox1.TabStop = false;
			pictureBox1.Visible = false;
			lblMessage.Font = new System.Drawing.Font("微软雅黑", 13f, System.Drawing.FontStyle.Bold);
			lblMessage.Location = new System.Drawing.Point(74, 78);
			lblMessage.Name = "lblMessage";
			lblMessage.Size = new System.Drawing.Size(363, 128);
			lblMessage.TabIndex = 9;
			lblMessage.Text = "警告：请考生坐姿正对考试手机前置摄像试手机前置摄像头头";
			picClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
			picClose.Image = SelfExamClient.Properties.Resources.CloseButton;
			picClose.Location = new System.Drawing.Point(178, 241);
			picClose.Name = "picClose";
			picClose.Size = new System.Drawing.Size(100, 35);
			picClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			picClose.TabIndex = 7;
			picClose.TabStop = false;
			picClose.Click += new System.EventHandler(picClose_Click);
			pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			pictureBox2.Image = SelfExamClient.Properties.Resources.Split;
			pictureBox2.Location = new System.Drawing.Point(1, 224);
			pictureBox2.Name = "pictureBox2";
			pictureBox2.Size = new System.Drawing.Size(478, 7);
			pictureBox2.TabIndex = 6;
			pictureBox2.TabStop = false;
			pictureBox4.Image = SelfExamClient.Properties.Resources.Warning;
			pictureBox4.Location = new System.Drawing.Point(29, 77);
			pictureBox4.Name = "pictureBox4";
			pictureBox4.Size = new System.Drawing.Size(25, 25);
			pictureBox4.TabIndex = 8;
			pictureBox4.TabStop = false;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.White;
			base.ClientSize = new System.Drawing.Size(480, 283);
			base.Controls.Add(panel1);
			base.Controls.Add(picClose);
			base.Controls.Add(pictureBox2);
			base.Controls.Add(lblMessage);
			base.Controls.Add(pictureBox4);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "PopContent";
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "考试平台";
			base.FormClosed += new System.Windows.Forms.FormClosedEventHandler(PopContent_FormClosed);
			base.Load += new System.EventHandler(PopContent_Load);
			base.Paint += new System.Windows.Forms.PaintEventHandler(PopContent_Paint);
			base.Resize += new System.EventHandler(PopContent_Resize);
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			((System.ComponentModel.ISupportInitialize)picClose).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
			ResumeLayout(false);
		}
	}
}
