using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using SelfExamClient.Properties;

namespace SelfExamClient.Controls
{
	public class MaskLayer : Control
	{
		private int _RectHeight = 300;

		private int _RectWidth = 450;

		private int _TitleHeight = 60;

		private Color _RectBorderColor = Color.FromArgb(245, 245, 245);

		private Color _RectBackColor = Color.White;

		private int _Alpha = 125;

		private IContainer components;

		[Category("DemoUI")]
		[Description("透明度\r\n范围：0~255（完全透明~完全不透明）\r\n默认：125（半透明）")]
		public int Alpha
		{
			get
			{
				return _Alpha;
			}
			set
			{
				if (value < 0)
				{
					value = 0;
				}
				if (value > 255)
				{
					value = 255;
				}
				_Alpha = value;
				Invalidate();
			}
		}

		[Category("DemoUI")]
		[Description("是否启用点击隐藏功能\r\n默认：否")]
		public bool EnabledClickHide { get; set; }

		[Category("LESLIE_UI")]
		[Description("是否处于显示状态")]
		[Browsable(false)]
		public bool IsShow { get; private set; } = true;


		public bool IsClose { get; set; }

		public MaskLayer()
		{
			SetStyle(ControlStyles.UserPaint, value: true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
			SetStyle(ControlStyles.Opaque, value: true);
			SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
			CreateControl();
			base.Visible = false;
			Dock = DockStyle.Fill;
		}

		protected override void OnClick(EventArgs e)
		{
			base.OnClick(e);
			if (EnabledClickHide)
			{
				HideMask();
			}
		}

		public static void DrawRoundRectangle(Graphics g, Pen pen, Rectangle rect, int cornerRadius)
		{
			using GraphicsPath path = CreateRoundedRectanglePath(rect, cornerRadius);
			g.DrawPath(pen, path);
		}

		public static void FillRoundRectangle(Graphics g, Brush brush, Rectangle rect, int cornerRadius)
		{
			using GraphicsPath path = CreateRoundedRectanglePath(rect, cornerRadius);
			g.FillPath(brush, path);
		}

		internal static GraphicsPath CreateRoundedRectanglePath(Rectangle rect, int cornerRadius)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			graphicsPath.AddArc(rect.X, rect.Y, cornerRadius * 2, cornerRadius * 2, 180f, 90f);
			graphicsPath.AddLine(rect.X + cornerRadius, rect.Y, rect.Right - cornerRadius * 2, rect.Y);
			graphicsPath.AddArc(rect.X + rect.Width - cornerRadius * 2, rect.Y, cornerRadius * 2, cornerRadius * 2, 270f, 90f);
			graphicsPath.AddLine(rect.Right, rect.Y + cornerRadius * 2, rect.Right, rect.Y + rect.Height - cornerRadius * 2);
			graphicsPath.AddArc(rect.X + rect.Width - cornerRadius * 2, rect.Y + rect.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0f, 90f);
			graphicsPath.AddLine(rect.Right - cornerRadius * 2, rect.Bottom, rect.X + cornerRadius * 2, rect.Bottom);
			graphicsPath.AddArc(rect.X, rect.Bottom - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90f, 90f);
			graphicsPath.AddLine(rect.X, rect.Bottom - cornerRadius * 2, rect.X, rect.Y + cornerRadius * 2);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			SolidBrush solidBrush = new SolidBrush(Color.FromArgb(_Alpha, BackColor));
			e.Graphics.FillRectangle(solidBrush, e.ClipRectangle);
			solidBrush.Dispose();
			int num = (FindForm().Width - _RectWidth) / 2;
			int num2 = (FindForm().Height - _RectHeight) / 2;
			FillRoundRectangle(e.Graphics, new SolidBrush(_RectBackColor), new Rectangle(num, num2, _RectWidth, _RectHeight), 8);
			DrawRoundRectangle(e.Graphics, new Pen(_RectBorderColor), new Rectangle(num, num2, _RectWidth, _RectHeight), 8);
			FillRoundRectangle(e.Graphics, new SolidBrush(_RectBorderColor), new Rectangle(num, num2, _RectWidth, _TitleHeight), 8);
			e.Graphics.FillRectangle(new SolidBrush(_RectBorderColor), new Rectangle(num, num2 + _TitleHeight - 8, 8, 8));
			e.Graphics.FillRectangle(new SolidBrush(_RectBorderColor), new Rectangle(num + _RectWidth - 8, num2 + _TitleHeight - 8, 8, 8));
			Font font = new Font("微软雅黑", 12f, FontStyle.Bold);
			SizeF sizeF = e.Graphics.MeasureString("警告提示", font);
			Point point = new Point(num + 20, num2 + Convert.ToInt32(((float)_TitleHeight - sizeF.Height) / 2f));
			e.Graphics.DrawString("警告提示", font, new SolidBrush(Color.Black), point);
			e.Graphics.DrawImage(Resources.Warning, num + 20, num2 + Convert.ToInt32(((float)_TitleHeight - sizeF.Height) / 2f) + 75, 30, 30);
			Font font2 = new Font("微软雅黑", 15f, FontStyle.Bold);
			e.Graphics.MeasureString(Text, font2);
			Point point2 = new Point(num + 55, num2 + Convert.ToInt32(((float)_TitleHeight - sizeF.Height) / 2f) + 80);
			if (Text.Length > 18)
			{
				if (Text.Length > 36)
				{
					e.Graphics.DrawString(Text.Substring(0, 18), font2, new SolidBrush(Color.Black), point2);
					e.Graphics.DrawString(Text.Substring(18, 18), font2, new SolidBrush(Color.Black), new Point(point2.X, point2.Y + font2.Height + 20));
					e.Graphics.DrawString(Text.Substring(36), font2, new SolidBrush(Color.Black), new Point(point2.X, point2.Y + (font2.Height + 20) * 2));
				}
				else
				{
					e.Graphics.DrawString(Text.Substring(0, 18), font2, new SolidBrush(Color.Black), point2);
					e.Graphics.DrawString(Text.Substring(18), font2, new SolidBrush(Color.Black), new Point(point2.X, point2.Y + font2.Height + 20));
				}
			}
			else
			{
				e.Graphics.DrawString(Text, font2, new SolidBrush(Color.Black), point2);
			}
		}

		public void ShowMask()
		{
			try
			{
				BeginInvoke((Action)delegate
				{
					IsShow = true;
					SendKeys.Send("{Tab}");
					BringToFront();
					base.Visible = true;
					BackColor = Color.Black;
					Show();
				});
			}
			catch (Exception)
			{
			}
		}

		public void HideMask()
		{
			try
			{
				BeginInvoke((Action)delegate
				{
					IsShow = false;
					SendToBack();
					base.Visible = false;
					Hide();
				});
			}
			catch (Exception)
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
	}
}
