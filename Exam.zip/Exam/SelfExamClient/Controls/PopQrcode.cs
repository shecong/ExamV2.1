using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using Newtonsoft.Json;
using SelfExamClient.Properties;
using SelfExamClient.Utils;

namespace SelfExamClient.Controls
{
	public class PopQrcode : Form
	{
		private PopMaskQ mq;

		private IContainer components;

		private Label label1;

		private PictureBox pictureBox1;

		private Panel panel1;

		private PictureBox pictureBox2;

		private Label label2;

		private Label label3;

		private Label label4;

		private System.Windows.Forms.Timer timer1;

		public PopMaskQ SetParent
		{
			set
			{
				mq = value;
			}
		}

		public PopQrcode()
		{
			InitializeComponent();
		}

		private void PopQrcode_Load(object sender, EventArgs e)
		{
			Common.MoveControlToCenter(label1, this);
			Common.MoveControlToCenter(label3, this);
			Common.MoveControlToCenter(label4, this);
			Common.MoveControlToCenter(panel1, this);
			Common.MoveControlToCenter(pictureBox1, this);
			pictureBox1.Image = Common.Base64ToIamge(HCos.Base64Qrode);
		}

		private void PopQrcode_Resize(object sender, EventArgs e)
		{
			SetWindowRegion();
		}

		public void SetWindowRegion()
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			Rectangle rect = new Rectangle(0, 0, base.Width, base.Height);
			graphicsPath = GetRoundedRectPath(rect, 10);
			base.Region = new Region(graphicsPath);
		}

		private GraphicsPath GetRoundedRectPath(Rectangle rect, int radius)
		{
			Rectangle rect2 = new Rectangle(rect.Location, new Size(radius, radius));
			GraphicsPath graphicsPath = new GraphicsPath();
			graphicsPath.AddArc(rect2, 180f, 90f);
			rect2.X = rect.Right - radius;
			graphicsPath.AddArc(rect2, 270f, 90f);
			rect2.Y = rect.Bottom - radius;
			graphicsPath.AddArc(rect2, 0f, 90f);
			rect2.X = rect.Left;
			graphicsPath.AddArc(rect2, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		private void PopQrcode_Paint(object sender, PaintEventArgs e)
		{
			Rectangle clientRectangle = base.ClientRectangle;
			Graphics graphics = e.Graphics;
			Pen pen = new Pen(Color.WhiteSmoke);
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics.CompositingQuality = CompositingQuality.HighQuality;
			graphics.DrawLine(pen, 0, 0, 0, clientRectangle.Height - 1);
			graphics.DrawLine(pen, 0, clientRectangle.Height - 1, clientRectangle.Width - 1, clientRectangle.Height - 1);
			graphics.DrawLine(pen, clientRectangle.Width - 1, clientRectangle.Height - 1, clientRectangle.Width - 1, 0);
			graphics.DrawLine(pen, clientRectangle.Width - 1, 0, 0, 0);
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			string obj = $"{HCos.Domain}{HCos.MessageUrl2}?examLogicId={HCos.examLogicId}&token={HCos.Token}";
			Common.WriteLog(obj + "          =           " + DateTime.Now.ToString());
			HttpAsyncRequestHelper.HttpAsyncRequest(obj, "get", CallBackFuc, new ObjectMessage());
		}

		private void CallBackFuc(object obj, string respStr, int statusCode, WebException e)
		{
			Common.WriteLog(respStr);
			if (statusCode == 200 && obj.GetType().Name == "ObjectMessage")
			{
				ObjectMessage objectMessage = JsonConvert.DeserializeObject<ObjectMessage>(respStr);
				if (objectMessage != null && objectMessage != null && !(objectMessage.message.ToString() == "false") && !(objectMessage.data != "1"))
				{
					ShowInfor("已连接");
					Thread.Sleep(2000);
					CloseWindow();
				}
			}
		}

		private void ShowInfor(string message)
		{
			if (message == "")
			{
				return;
			}
			if (base.InvokeRequired)
			{
				Invoke((MethodInvoker)delegate
				{
					ShowInfor(message);
				});
			}
			else
			{
				label2.Text = message;
				label2.ForeColor = Color.Green;
				pictureBox2.Image = Resources.Right;
			}
		}

		private void CloseWindow()
		{
			if (base.InvokeRequired)
			{
				Invoke((MethodInvoker)delegate
				{
					CloseWindow();
				});
			}
			else
			{
				Close();
			}
		}

		private void PopQrcode_FormClosed(object sender, FormClosedEventArgs e)
		{
			if (Application.OpenForms["PopMaskQ"] != null)
			{
				mq.ReturnSide();
				Application.OpenForms["PopMaskQ"].Close();
			}
			else if (mq != null)
			{
				mq.ReturnSide();
				mq.Close();
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			label1 = new System.Windows.Forms.Label();
			panel1 = new System.Windows.Forms.Panel();
			label2 = new System.Windows.Forms.Label();
			pictureBox2 = new System.Windows.Forms.PictureBox();
			label3 = new System.Windows.Forms.Label();
			label4 = new System.Windows.Forms.Label();
			timer1 = new System.Windows.Forms.Timer(components);
			pictureBox1 = new System.Windows.Forms.PictureBox();
			panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			SuspendLayout();
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font("微软雅黑", 12.5f, System.Drawing.FontStyle.Bold);
			label1.Location = new System.Drawing.Point(156, 6);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(78, 24);
			label1.TabIndex = 0;
			label1.Text = "警告提示";
			panel1.Controls.Add(label2);
			panel1.Controls.Add(pictureBox2);
			panel1.Location = new System.Drawing.Point(160, 345);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(125, 27);
			panel1.TabIndex = 2;
			label2.AutoSize = true;
			label2.Font = new System.Drawing.Font("微软雅黑", 11f, System.Drawing.FontStyle.Bold);
			label2.ForeColor = System.Drawing.Color.Red;
			label2.Location = new System.Drawing.Point(40, 4);
			label2.Name = "label2";
			label2.Size = new System.Drawing.Size(54, 19);
			label2.TabIndex = 1;
			label2.Text = "未连接";
			pictureBox2.Image = SelfExamClient.Properties.Resources.Warning;
			pictureBox2.Location = new System.Drawing.Point(11, 4);
			pictureBox2.Name = "pictureBox2";
			pictureBox2.Size = new System.Drawing.Size(19, 19);
			pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			pictureBox2.TabIndex = 0;
			pictureBox2.TabStop = false;
			label3.AutoSize = true;
			label3.Font = new System.Drawing.Font("微软雅黑", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 134);
			label3.Location = new System.Drawing.Point(139, 381);
			label3.Name = "label3";
			label3.Size = new System.Drawing.Size(202, 22);
			label3.TabIndex = 3;
			label3.Text = "系统检测到旁路监控已中断";
			label4.AutoSize = true;
			label4.Font = new System.Drawing.Font("微软雅黑", 9f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 134);
			label4.Location = new System.Drawing.Point(117, 404);
			label4.Name = "label4";
			label4.Size = new System.Drawing.Size(366, 17);
			label4.TabIndex = 4;
			label4.Text = "请使用考试监控APP重新扫描上方二维码打开监控，否则将视为违纪";
			timer1.Enabled = true;
			timer1.Interval = 1000;
			timer1.Tick += new System.EventHandler(timer1_Tick);
			pictureBox1.Location = new System.Drawing.Point(84, 30);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(320, 320);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			pictureBox1.TabIndex = 1;
			pictureBox1.TabStop = false;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.White;
			base.ClientSize = new System.Drawing.Size(566, 425);
			base.Controls.Add(label4);
			base.Controls.Add(label3);
			base.Controls.Add(panel1);
			base.Controls.Add(pictureBox1);
			base.Controls.Add(label1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "PopQrcode";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "考试平台";
			base.FormClosed += new System.Windows.Forms.FormClosedEventHandler(PopQrcode_FormClosed);
			base.Load += new System.EventHandler(PopQrcode_Load);
			base.Paint += new System.Windows.Forms.PaintEventHandler(PopQrcode_Paint);
			base.Resize += new System.EventHandler(PopQrcode_Resize);
			panel1.ResumeLayout(false);
			panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
