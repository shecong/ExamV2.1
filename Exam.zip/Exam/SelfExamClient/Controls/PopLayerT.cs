using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SelfExamClient.Controls
{
	public class PopLayerT : Control
	{
		private Timer myTimer = new Timer();

		private int _Alpha = 125;

		private IContainer components;

		[Category("DemoUI")]
		[Description("透明度\r\n范围：0~255（完全透明~完全不透明）\r\n默认：125（半透明）")]
		public int Alpha
		{
			get
			{
				return _Alpha;
			}
			set
			{
				if (value < 0)
				{
					value = 0;
				}
				if (value > 255)
				{
					value = 255;
				}
				_Alpha = value;
				Invalidate();
			}
		}

		public bool TextIsAlpha { get; set; }

		public Color BorderColor { get; set; } = Color.Black;


		public int BottomHeight { get; set; } = 120;


		[Category("DemoUI")]
		[Description("是否启用点击隐藏功能\r\n默认：否")]
		public bool EnabledClickHide { get; set; }

		[Category("LESLIE_UI")]
		[Description("是否处于显示状态")]
		[Browsable(false)]
		public bool IsShow { get; private set; } = true;


		public PopLayerT()
		{
			SetStyle(ControlStyles.UserPaint, value: true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
			SetStyle(ControlStyles.Opaque, value: true);
			SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
			CreateControl();
			base.Visible = false;
			Dock = DockStyle.None;
			base.Width = 1;
			base.Height = 1;
			myTimer.Interval = 3000;
			myTimer.Tick += MyTimer_Tick;
		}

		protected override void OnClick(EventArgs e)
		{
			base.OnClick(e);
			if (EnabledClickHide)
			{
				HideMask();
			}
		}

		protected override void WndProc(ref Message m)
		{
			if (m.Msg != 20)
			{
				base.WndProc(ref m);
			}
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Point point2 = (base.Location = new Point(Convert.ToInt32((FindForm().Width - base.Width) / 2), FindForm().Height - BottomHeight));
			SolidBrush solidBrush = new SolidBrush(Color.FromArgb(_Alpha, BackColor));
			e.Graphics.FillRectangle(solidBrush, e.ClipRectangle);
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.DrawRectangle(new Pen(BorderColor), 0, 0, base.Width - 1, base.Height - 1);
			SizeF sizeF = e.Graphics.MeasureString(Text, Font);
			Point point3 = new Point(Convert.ToInt32(((float)base.Width - sizeF.Width) / 2f), Convert.ToInt32(((float)base.Height - sizeF.Height) / 2f));
			if (TextIsAlpha)
			{
				e.Graphics.DrawString(Text, Font, new SolidBrush(Color.FromArgb(_Alpha, ForeColor)), point3);
			}
			else
			{
				e.Graphics.DrawString(Text, Font, new SolidBrush(ForeColor), point3);
			}
			solidBrush.Dispose();
		}

		private void MyTimer_Tick(object sender, EventArgs e)
		{
			HideMask();
		}

		public void ShowMask()
		{
			try
			{
				BeginInvoke((Action)delegate
				{
					IsShow = true;
					BringToFront();
					base.Visible = true;
					Show();
					myTimer.Enabled = true;
				});
			}
			catch (Exception)
			{
			}
		}

		public void HideMask()
		{
			try
			{
				BeginInvoke((Action)delegate
				{
					myTimer.Enabled = false;
					IsShow = false;
					SendToBack();
					base.Visible = false;
					FindForm().Controls.Remove(this);
				});
			}
			catch (Exception)
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
	}
}
