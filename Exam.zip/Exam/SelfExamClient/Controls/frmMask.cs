using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace SelfExamClient.Controls
{
	public class frmMask : Form
	{
		private int _Alpha = 125;

		private IContainer components;

		[Category("DemoUI")]
		[Description("透明度\r\n范围：0~255（完全透明~完全不透明）\r\n默认：125（半透明）")]
		public int Alpha
		{
			get
			{
				return _Alpha;
			}
			set
			{
				if (value < 0)
				{
					value = 0;
				}
				if (value > 255)
				{
					value = 255;
				}
				_Alpha = value;
				Invalidate();
			}
		}

		[Category("DemoUI")]
		[Description("是否启用点击隐藏功能\r\n默认：否")]
		public bool EnabledClickHide { get; set; }

		[Category("LESLIE_UI")]
		[Description("是否处于显示状态")]
		[Browsable(false)]
		public bool IsShow { get; private set; } = true;


		public frmMask()
		{
			InitializeComponent();
			SetStyle(ControlStyles.UserPaint, value: true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, value: true);
			SetStyle(ControlStyles.Opaque, value: true);
			SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
			CreateControl();
			base.Visible = false;
			Dock = DockStyle.None;
			base.Width = 1;
			base.Height = 1;
		}

		protected override void OnClick(EventArgs e)
		{
			base.OnClick(e);
			if (EnabledClickHide)
			{
				HideMask();
			}
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Font font = new Font("微软雅黑", 24f, FontStyle.Bold);
			SizeF sizeF = e.Graphics.MeasureString(Text, font);
			Rectangle bounds = Screen.GetBounds(this);
			Point point = new Point(Convert.ToInt32(((float)bounds.Width - sizeF.Width) / 2f), bounds.Height - 90);
			Point point2 = new Point(0, 0);
			SolidBrush solidBrush = new SolidBrush(Color.FromArgb(_Alpha, BackColor));
			if (Dock == DockStyle.Fill)
			{
				point2 = point;
			}
			else
			{
				base.Width = Convert.ToInt32(sizeF.Width) + 1;
				base.Height = Convert.ToInt32(sizeF.Height) + 1;
				base.Location = point;
			}
			e.Graphics.FillRectangle(solidBrush, e.ClipRectangle);
			e.Graphics.DrawString(Text, new Font("微软雅黑", 24f, FontStyle.Bold), new SolidBrush(ForeColor), point2);
			solidBrush.Dispose();
		}

		public void ShowMask()
		{
			try
			{
				BeginInvoke((Action)delegate
				{
					IsShow = true;
					base.Visible = true;
					BackColor = Color.Black;
				});
			}
			catch (Exception)
			{
			}
		}

		public void HideMask()
		{
			try
			{
				BeginInvoke((Action)delegate
				{
					IsShow = false;
					base.Visible = false;
					Close();
				});
			}
			catch (Exception)
			{
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			SuspendLayout();
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(284, 262);
			DoubleBuffered = true;
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "frmMask";
			base.ShowInTaskbar = false;
			Text = "考试平台";
			base.TopMost = true;
			ResumeLayout(false);
		}
	}
}
