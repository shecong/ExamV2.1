using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace SelfExamClient.Controls
{
	public class PopMask : Form
	{
		private string _Message;

		private IContainer components;

		public string Message
		{
			set
			{
				_Message = value;
			}
		}

		public PopMask()
		{
			InitializeComponent();
		}

		private void PopMask_Load(object sender, EventArgs e)
		{
			base.Opacity = 0.4;
			PopContent popContent = new PopContent();
			popContent.TopMost = true;
			popContent.Message = _Message;
			popContent.Show();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			SuspendLayout();
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.DarkGray;
			base.ClientSize = new System.Drawing.Size(284, 262);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "PopMask";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			Text = "考试平台";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(PopMask_Load);
			ResumeLayout(false);
		}
	}
}
