using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using SelfExamClient.WinForms;

namespace SelfExamClient.Controls
{
	public class PopMaskQ : Form
	{
		private string _Message;

		private frmOpen open;

		private IContainer components;

		public string Message
		{
			set
			{
				_Message = value;
			}
		}

		public frmOpen SetParent
		{
			set
			{
				open = value;
			}
		}

		public PopMaskQ()
		{
			InitializeComponent();
		}

		public void ReturnSide()
		{
			open.ReviewT();
		}

		private void PopMask_Load(object sender, EventArgs e)
		{
			base.Opacity = 0.4;
			PopQrcode popQrcode = new PopQrcode();
			popQrcode.SetParent = this;
			popQrcode.TopMost = true;
			popQrcode.Show();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			SuspendLayout();
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.DarkGray;
			base.ClientSize = new System.Drawing.Size(284, 262);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "PopMaskQ";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			Text = "考试平台";
			base.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			base.Load += new System.EventHandler(PopMask_Load);
			ResumeLayout(false);
		}
	}
}
