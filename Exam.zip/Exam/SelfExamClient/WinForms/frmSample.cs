using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using SelfExamClient.Controls;
using SelfExamClient.Utils;

namespace SelfExamClient.WinForms
{
	public class frmSample : Form
	{
		private bool multiThreadedMessageLoopEnabled;

		private string targetUrl;

		private frmMain main;

		private IContainer components;

		private Panel panel2;

		public frmSample(string targUrl, bool _multiThreadedMessageLoopEnabled, frmMain _parentMain)
		{
			InitializeComponent();
			SelfExamClient.Utils.Windows.SetWindowText(base.Handle.ToInt32(), "考试平台");
			base.WindowState = FormWindowState.Maximized;
			targetUrl = targUrl;
			main = _parentMain;
			base.Load += BrowserFormLoad;
			base.Resize += FrmOpen_Resize;
			multiThreadedMessageLoopEnabled = _multiThreadedMessageLoopEnabled;
			base.TopMost = true;
		}

		private void FrmOpen_Resize(object sender, EventArgs e)
		{
		}

		private void BrowserFormLoad(object sender, EventArgs e)
		{
			BrowserTabUserControl value = new BrowserTabUserControl(targetUrl, multiThreadedMessageLoopEnabled)
			{
				Dock = DockStyle.Fill
			};
			panel2.Controls.Add(value);
		}

		private void frmOpen_FormClosing(object sender, FormClosingEventArgs e)
		{
			try
			{
				if (panel2.Controls.Count > 0)
				{
					((BrowserTabUserControl)panel2.Controls[0]).Browser.GetBrowser().CloseBrowser(forceClose: false);
				}
				if (Environment.OSVersion.Version.Major > 6)
				{
					Dispose(disposing: true);
				}
				if (main != null)
				{
					main.TopMost = true;
				}
			}
			catch
			{
			}
		}

		private void pictureBox1_Click_1(object sender, EventArgs e)
		{
			Close();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			panel2 = new System.Windows.Forms.Panel();
			SuspendLayout();
			panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			panel2.Location = new System.Drawing.Point(0, 0);
			panel2.Name = "panel2";
			panel2.Size = new System.Drawing.Size(1138, 652);
			panel2.TabIndex = 4;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(1138, 652);
			base.Controls.Add(panel2);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "frmSample";
			Text = "考试平台";
			ResumeLayout(false);
		}
	}
}
