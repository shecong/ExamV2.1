using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using CefSharp;
using SelfExamClient.Controls;
using SelfExamClient.Properties;
using SelfExamClient.Utils;

namespace SelfExamClient.WinForms
{
	public class MainForm : Form
	{
		private delegate void AddTabCallback(TabPage tabPage);

		private bool multiThreadedMessageLoopEnabled;

		private TabPage tabPage;

		private Thread demoThread;

		private IContainer components;

		private TabControl browserTabControl;

		private ToolStrip toolStrip1;

		private ToolStripButton toolStripButton1;

		public MainForm(bool multiThreadedMessageLoopEnabled)
		{
			InitializeComponent();
			base.WindowState = FormWindowState.Maximized;
			base.Load += BrowserFormLoad;
			base.ResizeBegin += delegate
			{
				SuspendLayout();
			};
			base.ResizeEnd += delegate
			{
				ResumeLayout(performLayout: true);
			};
			this.multiThreadedMessageLoopEnabled = multiThreadedMessageLoopEnabled;
		}

		private void BrowserFormLoad(object sender, EventArgs e)
		{
			string setValueByKey = AppConfigHelper.GetSetValueByKey("url");
			DefaultTab("首页", setValueByKey);
		}

		public void RemoveTab(IntPtr windowHandle)
		{
			Control control = Control.FromChildHandle(windowHandle);
			if (!control.IsDisposed)
			{
				if (control.Parent is TabPage)
				{
					TabPage value = (TabPage)control.Parent;
					browserTabControl.TabPages.Remove(value);
				}
				else if (control.Parent is Panel)
				{
					TabPage value2 = (TabPage)((BrowserTabUserControl)((Panel)control.Parent).Parent).Parent;
					browserTabControl.TabPages.Remove(value2);
				}
			}
		}

		private void CloseCurrentTab()
		{
			if (browserTabControl.TabPages.Count != 0 && browserTabControl.TabPages.Count != 1)
			{
				int selectedIndex = browserTabControl.SelectedIndex;
				TabPage tabPage = browserTabControl.TabPages[selectedIndex];
				BrowserTabUserControl currentTabControl = GetCurrentTabControl();
				if (currentTabControl != null && !currentTabControl.IsDisposed)
				{
					currentTabControl = null;
				}
				browserTabControl.TabPages.Remove(tabPage);
				tabPage.Dispose();
				browserTabControl.SelectedIndex = selectedIndex - 1;
			}
		}

		private BrowserTabUserControl GetCurrentTabControl()
		{
			if (browserTabControl.SelectedIndex == -1)
			{
				return null;
			}
			return browserTabControl.Controls[browserTabControl.SelectedIndex].Controls[0] as BrowserTabUserControl;
		}

		public void AddTab(Control browserHostControl, string text)
		{
			browserTabControl.SuspendLayout();
			tabPage = new TabPage(text)
			{
				Dock = DockStyle.Fill
			};
			tabPage.Text = "考试系统";
			tabPage.Controls.Add(browserHostControl);
			browserTabControl.TabPages.Add(tabPage);
			browserTabControl.SelectedTab = tabPage;
			browserTabControl.ResumeLayout(performLayout: true);
		}

		private void DefaultTab(string title, string url)
		{
			browserTabControl.SuspendLayout();
			BrowserTabUserControl browserTabUserControl = new BrowserTabUserControl(url, multiThreadedMessageLoopEnabled)
			{
				Dock = DockStyle.Fill
			};
			TabPage tabPage = new TabPage(title)
			{
				Dock = DockStyle.Fill
			};
			browserTabUserControl.CreateControl();
			tabPage.Controls.Add(browserTabUserControl);
			browserTabControl.TabPages.Add(tabPage);
			browserTabControl.SelectedTab = tabPage;
			browserTabControl.ResumeLayout(performLayout: true);
		}

		private void BrowserForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			Cef.Shutdown();
			Environment.Exit(0);
		}

		private void toolStripLabel1_Click(object sender, EventArgs e)
		{
			CloseCurrentTab();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			browserTabControl = new System.Windows.Forms.TabControl();
			toolStrip1 = new System.Windows.Forms.ToolStrip();
			toolStripButton1 = new System.Windows.Forms.ToolStripButton();
			toolStrip1.SuspendLayout();
			SuspendLayout();
			browserTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
			browserTabControl.Location = new System.Drawing.Point(0, 25);
			browserTabControl.Name = "browserTabControl";
			browserTabControl.SelectedIndex = 0;
			browserTabControl.Size = new System.Drawing.Size(800, 425);
			browserTabControl.TabIndex = 5;
			toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[1] { toolStripButton1 });
			toolStrip1.Location = new System.Drawing.Point(0, 0);
			toolStrip1.Name = "toolStrip1";
			toolStrip1.Size = new System.Drawing.Size(800, 25);
			toolStrip1.TabIndex = 6;
			toolStrip1.Text = "toolStrip1";
			toolStripButton1.Image = SelfExamClient.Properties.Resources.close;
			toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
			toolStripButton1.Name = "toolStripButton1";
			toolStripButton1.Size = new System.Drawing.Size(88, 22);
			toolStripButton1.Text = "关闭当前页";
			toolStripButton1.Click += new System.EventHandler(toolStripLabel1_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(800, 450);
			base.Controls.Add(browserTabControl);
			base.Controls.Add(toolStrip1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "MainForm";
			Text = "考试系统";
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(BrowserForm_FormClosing);
			toolStrip1.ResumeLayout(false);
			toolStrip1.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
