using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Timers;
using System.Windows.Forms;
using Newtonsoft.Json;
using SelfExamClient.Controls;
using SelfExamClient.Utils;

namespace SelfExamClient.WinForms
{
	public class frmMain : Form
	{
		private delegate void SetTopCallBack(Color c);

		private delegate void showControlDelegate();

		private delegate void StopTimerCallBack();

		private bool multiThreadedMessageLoopEnabled;

		private Dictionary<string, string> dicExploer;

		public const int WM_DEVICECHANGE = 537;

		public const int DBT_DEVICEARRIVAL = 32768;

		public const int DBT_CONFIGCHANGECANCELED = 25;

		public const int DBT_CONFIGCHANGED = 24;

		public const int DBT_CUSTOMEVENT = 32774;

		public const int DBT_DEVICEQUERYREMOVE = 32769;

		public const int DBT_DEVICEQUERYREMOVEFAILED = 32770;

		public const int DBT_DEVICEREMOVECOMPLETE = 32772;

		public const int DBT_DEVICEREMOVEPENDING = 32771;

		public const int DBT_DEVICETYPESPECIFIC = 32773;

		public const int DBT_DEVNODES_CHANGED = 7;

		public const int DBT_QUERYCHANGECONFIG = 23;

		public const int DBT_USERDEFINED = 65535;

		private const int WM_QUERYENDSESSION = 17;

		public BrowserTabUserControl browser;

		private const int AW_SLIDE = 262144;

		private const int AW_ACTIVATE = 131072;

		private const int AW_BLEND = 524288;

		private Thread updateThread;

		public string currUrl = "";

		private Label lblip = new Label();

		private PictureBox picip = new PictureBox();

		private PopLayerT popLayerT = new PopLayerT();

		private bool blDebug;

		public System.Timers.Timer myTimer;

		private Stack<MsgObject> stk = new Stack<MsgObject>();

		private IContainer components;

		private PictureBox pictureBox1;

		private System.Windows.Forms.Timer timer1;

		private System.Windows.Forms.Timer timer2;

		protected override CreateParams CreateParams
		{
			get
			{
				CreateParams obj = base.CreateParams;
				//obj.ExStyle &= -262145;
				//obj.ExStyle |= 128;
				return obj;
			}
		}

		[DllImport("imm32.dll")]
		public static extern IntPtr ImmGetContext(IntPtr hwnd);

		[DllImport("imm32.dll")]
		public static extern bool ImmSetOpenStatus(IntPtr himc, bool b);

		[DllImport("user32")]
		private static extern bool AnimateWindow(IntPtr hwnd, int dwTime, int dwFlags);

		public frmMain(bool _multiThreadedMessageLoopEnabled)
		{
			InitializeComponent();
			base.WindowState = FormWindowState.Maximized;
			base.Load += BrowserFormLoad;
			base.ResizeBegin += delegate
			{
				SuspendLayout();
			};
			base.ResizeEnd += delegate
			{
				ResumeLayout(performLayout: true);
			};
			multiThreadedMessageLoopEnabled = _multiThreadedMessageLoopEnabled;
			base.TopMost = true;
			//dicExploer = new Dictionary<string, string>();
			//dicExploer.Add("iexplore", "iexplore");
			//dicExploer.Add("sogouexplorer", "sogouexplorer");
			//dicExploer.Add("the world", "the world");
			//dicExploer.Add("theworld", "the world");
			//dicExploer.Add("chrome", "chrome");
			//dicExploer.Add("firefox", "firefox");
			//dicExploer.Add("opera", "opera");
			//dicExploer.Add("360se", "360se");
			//dicExploer.Add("360chrome", "360chrome");
			//dicExploer.Add("safari", "safari");
			//dicExploer.Add("maxthon", "maxthon");
			//dicExploer.Add("netscape", "netscape");
			//dicExploer.Add("qqbrowser", "qqbrowser");
			//dicExploer.Add("baidubrowser", "baidubrowser");
			//dicExploer.Add("liebao", "liebao");
			//dicExploer.Add("microsoftedge", "microsoftedge");
			//dicExploer.Add("microsoftedgecp", "microsoftedgecp");
			//dicExploer.Add("taskmgr", "taskmgr");
			//dicExploer.Add("tsbrowser", "tsbrowser");
			//dicExploer.Add("qq", "qq");
			//dicExploer.Add("tim", "tim");
			//dicExploer.Add("teamviewer", "teamviewer");
			//dicExploer.Add("todesk", "todesk");
			//dicExploer.Add("anydesk", "anydesk");
			//dicExploer.Add("sunloginclient", "sunloginclient");
			//KillSoft();
			//Common.Protect(base.Handle);
			HCos.currentMain = this;
			base.Controls.Add(popLayerT);
			popLayerT.EnabledClickHide = true;
			popLayerT.Dock = DockStyle.None;
			popLayerT.ForeColor = Color.Red;
			popLayerT.Alpha = 0;
			popLayerT.Text = "";
			DictData();
			updateThread = new Thread(AutoUpdate);
			updateThread.Start();
			HCos.PantInterval = 30; 
            timer2.Interval = HCos.PantInterval * 1000;
			timer2.Enabled = true;
			myTimer = new System.Timers.Timer();
			myTimer.Interval = 1000.0;
			myTimer.Elapsed += MyTimer_Elapsed;
			myTimer.Start();
		}

		private void KillSoft()
		{
			try
			{
				Process[] processes = Process.GetProcesses();
				foreach (Process process in processes)
				{
					try
					{
						process.ProcessName.Replace(".exe", "").ToLower();
						if (dicExploer.ContainsKey(process.ProcessName.ToLower()))
						{
							process.Kill();
							continue;
						}
						string executablePathAboveVista = Common.GetExecutablePathAboveVista(process.Id);
						if (executablePathAboveVista == "")
						{
							continue;
						}
						FileVersionInfo versionInfo = FileVersionInfo.GetVersionInfo(executablePathAboveVista);
						if (versionInfo.OriginalFilename != null)
						{
							if (versionInfo.OriginalFilename.ToLower().IndexOf("sunloginclient") >= 0 || versionInfo.CompanyName.IndexOf("贝锐") >= 0)
							{
								process.Kill();
							}
							else if (versionInfo.OriginalFilename.ToLower().IndexOf("todesk") >= 0 || versionInfo.CompanyName.IndexOf("有趣") >= 0)
							{
								process.Kill();
							}
							else if (versionInfo.OriginalFilename.ToLower().IndexOf("teamviewer") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("anywhere") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("cloudx") >= 0)
							{
								process.Kill();
							}
							else if (versionInfo.OriginalFilename.ToLower().IndexOf("splashtop") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("logmein") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("gotomypc") >= 0)
							{
								process.Kill();
							}
							else if (versionInfo.OriginalFilename.ToLower().IndexOf("radmin") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("connectwise") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("ultravnc") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("remotepc") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("remotedesktop") >= 0)
							{
								process.Kill();
							}
							else if (versionInfo.OriginalFilename.ToLower().IndexOf("mstsc") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("wechat") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("dingtalk") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("钉钉") >= 0)
							{
								process.Kill();
							}
							else if (versionInfo.OriginalFilename.ToLower().IndexOf("wemeet") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("tencent") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("dingtalk") >= 0 || versionInfo.OriginalFilename.ToLower().IndexOf("会议") >= 0)
							{
								process.Kill();
							}
						}
					}
					catch (Exception ex)
					{
						Common.WriteLog($"......关闭进程异常：{ex.Message}");
					}
				}
			}
			catch (Exception ex2)
			{
				Common.WriteLog($"......关闭进程异常：{ex2.Message}");
				Console.WriteLine(ex2.Message);
			}
		}

		private void BrowserFormLoad(object sender, EventArgs e)
		{
			try
			{
				//clsAPI.HideTask(isHide: true);
				//clsAPI.Hook_Start();
				//clsAPI.TaskMgrLocking(bLock: true);
				ResponseIP();
				DefaultTab("首页", HCos.SUrl);
				HCos.dictWnd = new Dictionary<IntPtr, Window>();
				timer1.Enabled = true;
				timer1.Start();
				Focus();
				base.TopMost = false;
			}
			catch (Exception)
			{
			}
		}

		private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
		{
			clsAPI.HideTask(isHide: false);
			clsAPI.Hook_Clear();
			clsAPI.TaskMgrLocking(bLock: false);
			try
			{
				if (HCos.isHideAll == "1")
				{
					foreach (Window value in HCos.dictWnd.Values)
					{
						value.Visible = true;
					}
				}
			}
			catch
			{
			}
			StopProcess(Process.GetCurrentProcess().Id);
		}

		protected override void WndProc(ref Message m)
		{
			try
			{
				if (m.Msg == 537)
				{
					switch (m.WParam.ToInt32())
					{
					case 32768:
						m.Result = (IntPtr)0;
						break;
					case 32772:
						m.Result = (IntPtr)0;
						break;
					}
				}
			}
			catch (Exception)
			{
			}
			base.WndProc(ref m);
		}

		private void DefaultTab(string title, string url)
		{
			browser = new BrowserTabUserControl(url, multiThreadedMessageLoopEnabled)
			{
				Dock = DockStyle.Fill
			};
			base.Controls.Add(browser);
			browser.Width = base.Width;
			browser.Height = base.Height;
			if (HCos.IP != "")
			{
				Point location = new Point(Screen.PrimaryScreen.WorkingArea.Width - 200, Screen.PrimaryScreen.WorkingArea.Height + 10);
				picip.BackColor = HCos.GetPixelColor(location.X, location.Y);
				picip.Location = location;
				picip.SizeMode = PictureBoxSizeMode.AutoSize;
				base.Controls.Add(picip);
				picip.BringToFront();
				picip.Visible = false;
			}
		}

		public void SetTM(Color c)
		{
			if (picip.InvokeRequired)
			{
				SetTopCallBack method = SetTM;
				Invoke(method, c);
			}
			else
			{
				picip.BackColor = c;
				Bitmap image = new Bitmap(110, 20);
				Graphics.FromImage(image).DrawString(font: new Font("Times New Roman", 9f), brush: new SolidBrush(Color.Black), s: "IP:" + HCos.IP, x: 0f, y: 0f);
				picip.Image = image;
				picip.Visible = true;
			}
		}

		public static void StopProcess(string processName)
		{
			try
			{
				Console.WriteLine(processName);
				Process[] processesByName = Process.GetProcessesByName(processName);
				Console.WriteLine(processesByName.Length);
				Process[] array = processesByName;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].Kill();
				}
			}
			catch (Exception)
			{
			}
		}

		public static void StopProcess(int pid)
		{
			try
			{
				Process[] processes = Process.GetProcesses();
				Console.WriteLine(processes.Length);
				Process[] array = processes;
				foreach (Process process in array)
				{
					if (process.Id == pid)
					{
						process.Kill();
					}
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public void ChangeUrl()
		{
			base.Controls.Clear();
			DefaultTab("首页", HCos.Domain + "/examinee");
		}

		public void GotoUrl()
		{
			if (!HCos.IsErrorState)
			{
				base.Controls.Clear();
				DefaultTab("首页", HCos.errUrl);
				HCos.IsErrorState = true;
			}
		}

		private void ResponseIP()
		{
			try
			{
				string requestUriString = HCos.Domain + HCos.IpUrl;
				if (HCos.Domain.ToLower().IndexOf("hnexams") > 0)
				{
					requestUriString = HCos.Domain.ToLower().Replace("hnexams", HCos.IpUrl);
				}
				HttpWebRequest obj = (HttpWebRequest)WebRequest.Create(requestUriString);
				obj.Timeout = 5000;
				obj.Method = "GET";
				HCos.IP = HCos.GetValue(new StreamReader(((HttpWebResponse)obj.GetResponse()).GetResponseStream()).ReadToEnd(), "<h3 class=\"title\">", "</h3>");
			}
			catch
			{
				HCos.IP = "";
			}
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				Process[] processes = Process.GetProcesses();
				foreach (Process process in processes)
				{
					try
					{
						process.ProcessName.Replace(".exe", "").ToLower();
						if (dicExploer.ContainsKey(process.ProcessName.ToLower()))
						{
							process.Kill();
						}
					}
					catch (Exception ex)
					{
						Common.WriteLog($"......关闭进程异常：{ex.Message}");
					}
				}
			}
			catch (Exception ex2)
			{
				Common.WriteLog($"......关闭进程异常：{ex2.Message}");
				Console.WriteLine(ex2.Message);
			}
			try
			{
				ClearMemory();
				if (!(HCos.isHideAll == "1"))
				{
					return;
				}
				foreach (Window item in new SelfExamClient.Utils.Windows(Invisible: false, Untitled: false))
				{
					if (item.Title.IndexOf("高中学业水平考试") < 0 && item.Title.IndexOf("考试平台") < 0 && item.Title.IndexOf("自动更新") < 0 && item.Title.IndexOf("考试系统") < 0 && item.Title.IndexOf("计算机化考试") < 0 && item.Title.IndexOf("手写板") < 0 && item.Title.IndexOf("TrailsShowFrom") < 0)
					{
						if (!HCos.dictWnd.ContainsKey(item.hWnd))
						{
							HCos.dictWnd.Add(item.hWnd, item);
						}
						if (item.Visible)
						{
							item.Visible = false;
						}
					}
				}
			}
			catch
			{
			}
		}

		[DllImport("kernel32.dll")]
		public static extern int SetProcessWorkingSetSize(IntPtr process, int minSize, int maxSize);

		public static void ClearMemory()
		{
			GC.Collect();
			GC.WaitForPendingFinalizers();
			if (Environment.OSVersion.Platform == PlatformID.Win32NT)
			{
				SetProcessWorkingSetSize(Process.GetCurrentProcess().Handle, -1, -1);
			}
		}

		public void ShowContorl()
		{
			if (popLayerT.InvokeRequired)
			{
				popLayerT.Invoke(new showControlDelegate(ShowContorl));
			}
			else
			{
				popLayerT.ShowMask();
			}
		}

		public void InvokeControl()
		{
		}

		private void DictData()
		{
			HttpAsyncRequestHelper.HttpAsyncRequest(HCos.Domain + HCos.DictPath, "get", CallBackFuc, new DictObject());
		}

		private void CallBackFuc(object obj, string respStr, int statusCode, WebException e)
		{
			if (obj.GetType().Name == "DictObject")
			{
				HCos.dictObjects = JsonConvert.DeserializeObject<DictObject>(respStr);
			}
			else if (obj.GetType().Name == "ServerMessageObject")
			{
				ServerMessageObject smObj = JsonConvert.DeserializeObject<ServerMessageObject>(respStr);
				ShowMessage(smObj);
			}
		}

		private void ShowMessage(ServerMessageObject smObj)
		{
			if (smObj == null || smObj.data == null)
			{
				return;
			}
			string text = "";
			for (int i = 0; i < smObj.data.msgList.Count; i++)
			{
				text = smObj.data.msgList[i].msgContent;
				if (!(text == ""))
				{
					MsgObject msgObject = new MsgObject();
					msgObject.MsgType = "1";
					msgObject.Message = text;
					stk.Push(msgObject);
				}
			}
		}

		private void AutoUpdate()
		{
			//try
			//{
			//	if (!(HCos.UpdateUrl == "") && !(HCos.UpdateLocalFile == ""))
			//	{
			//		AutoUpdate autoUpdate = JsonConvert.DeserializeObject<AutoUpdate>(Common.GetWebRequest(HCos.UpdateUrl, ""));
			//		string keyValue = Common.GetKeyValue(HCos.UpdateLocalFile, "CurrVersion");
			//		if (autoUpdate != null && !(keyValue == "") && Convert.ToSingle(autoUpdate.version) > Convert.ToSingle(keyValue))
			//		{
			//			string[] array = new string[3] { autoUpdate.url, autoUpdate.start, autoUpdate.version };
			//			array[0] = autoUpdate.url;
			//			array[1] = autoUpdate.start;
			//			array[2] = autoUpdate.version;
			//			StartProcess(Environment.CurrentDirectory + "\\Update.exe", array);
			//			frmMain_FormClosed(null, null);
			//		}
			//	}
			//}
			//catch (Exception)
			//{
			//}
		}

		public bool StartProcess(string filename, string[] args)
		{
			try
			{
				string text = "";
				foreach (string text2 in args)
				{
					text = text + text2 + " ";
				}
				text = text.Trim();
				Process process = new Process();
				ProcessStartInfo processStartInfo2 = (process.StartInfo = new ProcessStartInfo(filename, text));
				process.StartInfo.UseShellExecute = false;
				process.Start();
				return true;
			}
			catch (Exception ex)
			{
				MessageBox.Show("启动应用程序时出错！原因：" + ex.Message);
			}
			return false;
		}

		private void timer2_Tick(object sender, EventArgs e)
		{
			if (!(HCos.examLogicId == ""))
			{
				HttpAsyncRequestHelper.HttpAsyncRequest($"{HCos.Domain}{HCos.MessageUrl}?examUid={HCos.examUID}&examLogicId={HCos.examLogicId}", "get", CallBackFuc, new ServerMessageObject());
			}
		}

		private void MyTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (stk.Count > 0)
			{
				MsgObject msgObject = stk.Pop();
				PopMask obj = new PopMask
				{
					Message = msgObject.Message
				};
				myTimer.Enabled = false;
				obj.ShowDialog();
				myTimer.Enabled = true;
			}
		}

		public void StopTimer()
		{
			if (base.InvokeRequired)
			{
				StopTimerCallBack method = StopTimer;
				Invoke(method, null);
			}
			else
			{
				timer2.Enabled = false;
				myTimer.Enabled = false;
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(482, 256);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(88, 87);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 300;
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(1124, 663);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.Text = "考试平台";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

		}
	}
}
