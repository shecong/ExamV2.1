using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using SelfExamClient.Properties;
using SelfExamClient.Utils;

namespace SelfExamClient.WinForms
{
	public class frmCJPass : Form
	{
		private IContainer components;

		private Button btnClose;

		private Button btnQuit;

		private TextBox textBox1;

		private Label label1;

		private PictureBox pictureBox1;

		private Panel panel1;

		public frmCJPass()
		{
			InitializeComponent();
			SelfExamClient.Utils.Windows.SetWindowText(base.Handle.ToInt32(), "考试平台");
		}

		private void frmCJPass_Load(object sender, EventArgs e)
		{
			HCos.CreateImagePictureBox(ref pictureBox1, Color.Black);
			base.AcceptButton = btnQuit;
			base.CancelButton = btnClose;
			HCos.IsOpen = true;
			clsAPI.SetWindowPos(base.Handle, -1, 0, 0, 0, 0, 3);
		}

		private void frmCJPass_FormClosing(object sender, FormClosingEventArgs e)
		{
			HCos.IsOpen = false;
		}

		private void btnClose_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void btnQuit_Click(object sender, EventArgs e)
		{
			if (textBox1.Text != HCos.supperPassword)
			{
				MessageBox.Show("密码错误");
				return;
			}
			try
			{
				clsAPI.HideTask(isHide: false);
				clsAPI.Hook_Clear();
				clsAPI.TaskMgrLocking(bLock: false);
				try
				{
					if (HCos.isHideAll == "1")
					{
						foreach (Window value in HCos.dictWnd.Values)
						{
							value.Visible = true;
						}
					}
				}
				catch
				{
				}
			}
			catch
			{
			}
			StopProcess(Process.GetCurrentProcess().Id);
		}

		public static void StopProcess(string processName)
		{
			try
			{
				Console.WriteLine("进程名称：" + processName);
				Process[] processesByName = Process.GetProcessesByName(processName);
				Console.WriteLine(processesByName.Length);
				Process[] array = processesByName;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].Kill();
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public static void StopProcess(int pid)
		{
			try
			{
				Process[] processes = Process.GetProcesses();
				Console.WriteLine(processes.Length);
				Process[] array = processes;
				foreach (Process process in array)
				{
					if (process.Id == pid)
					{
						process.Kill();
					}
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			btnClose = new System.Windows.Forms.Button();
			btnQuit = new System.Windows.Forms.Button();
			textBox1 = new System.Windows.Forms.TextBox();
			label1 = new System.Windows.Forms.Label();
			pictureBox1 = new System.Windows.Forms.PictureBox();
			panel1 = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			SuspendLayout();
			btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			btnClose.Location = new System.Drawing.Point(271, 195);
			btnClose.Name = "btnClose";
			btnClose.Size = new System.Drawing.Size(101, 23);
			btnClose.TabIndex = 7;
			btnClose.Text = "取消";
			btnClose.UseVisualStyleBackColor = true;
			btnClose.Click += new System.EventHandler(btnClose_Click);
			btnQuit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			btnQuit.Location = new System.Drawing.Point(134, 195);
			btnQuit.Name = "btnQuit";
			btnQuit.Size = new System.Drawing.Size(101, 23);
			btnQuit.TabIndex = 8;
			btnQuit.Text = "退出";
			btnQuit.UseVisualStyleBackColor = true;
			btnQuit.Click += new System.EventHandler(btnQuit_Click);
			textBox1.Location = new System.Drawing.Point(160, 109);
			textBox1.Name = "textBox1";
			textBox1.PasswordChar = '*';
			textBox1.Size = new System.Drawing.Size(226, 21);
			textBox1.TabIndex = 6;
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font("微软雅黑", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 134);
			label1.Location = new System.Drawing.Point(98, 106);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(69, 26);
			label1.TabIndex = 5;
			label1.Text = "密码：";
			pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			pictureBox1.Image = SelfExamClient.Properties.Resources.logoks;
			pictureBox1.Location = new System.Drawing.Point(-1, 0);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(168, 37);
			pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			pictureBox1.TabIndex = 4;
			pictureBox1.TabStop = false;
			panel1.BackColor = System.Drawing.Color.Black;
			panel1.Location = new System.Drawing.Point(0, 0);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(483, 37);
			panel1.TabIndex = 9;
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.AntiqueWhite;
			base.ClientSize = new System.Drawing.Size(481, 261);
			base.Controls.Add(btnClose);
			base.Controls.Add(btnQuit);
			base.Controls.Add(textBox1);
			base.Controls.Add(label1);
			base.Controls.Add(pictureBox1);
			base.Controls.Add(panel1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "frmCJPass";
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(frmCJPass_FormClosing);
			base.Load += new System.EventHandler(frmCJPass_Load);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
