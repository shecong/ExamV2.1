using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using SelfExamClient.Properties;
using SelfExamClient.Utils;

namespace SelfExamClient.WinForms
{
	public class frmOnline : Form
	{
		private IContainer components;

		private PictureBox pictureBox1;

		private LinkLabel linkLabel1;

		private Label label1;

		private LinkLabel linkLabel2;

		private Button btnClose;

		public frmOnline()
		{
			InitializeComponent();
			SelfExamClient.Utils.Windows.SetWindowText(base.Handle.ToInt32(), "在线考试客户端");
		}

		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			HCos.Domain = HCos.DomainOne;
			HCos.currentMain.ChangeUrl();
			Close();
		}

		private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			HCos.Domain = HCos.DomainTwo;
			HCos.currentMain.ChangeUrl();
			Close();
		}

		private void frmOnline_FormClosing(object sender, FormClosingEventArgs e)
		{
			HCos.IsOpenOnline = false;
		}

		private void frmOnline_Load(object sender, EventArgs e)
		{
			HCos.CreateImagePictureBox(ref pictureBox1, Color.Black);
			HCos.IsOpenOnline = true;
			base.CancelButton = btnClose;
			clsAPI.SetWindowPos(base.Handle, -1, 0, 0, 0, 0, 3);
		}

		private void btnClose_Click(object sender, EventArgs e)
		{
			Close();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			pictureBox1 = new System.Windows.Forms.PictureBox();
			linkLabel1 = new System.Windows.Forms.LinkLabel();
			label1 = new System.Windows.Forms.Label();
			linkLabel2 = new System.Windows.Forms.LinkLabel();
			btnClose = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			SuspendLayout();
			pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			pictureBox1.Image = SelfExamClient.Properties.Resources.logoah;
			pictureBox1.Location = new System.Drawing.Point(-1, 0);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new System.Drawing.Size(483, 37);
			pictureBox1.TabIndex = 4;
			pictureBox1.TabStop = false;
			linkLabel1.AutoSize = true;
			linkLabel1.Font = new System.Drawing.Font("宋体", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 134);
			linkLabel1.Location = new System.Drawing.Point(211, 112);
			linkLabel1.Name = "linkLabel1";
			linkLabel1.Size = new System.Drawing.Size(76, 16);
			linkLabel1.TabIndex = 5;
			linkLabel1.TabStop = true;
			linkLabel1.Text = "主服务器";
			linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(linkLabel1_LinkClicked);
			label1.AutoSize = true;
			label1.Font = new System.Drawing.Font("宋体", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 134);
			label1.Location = new System.Drawing.Point(60, 111);
			label1.Name = "label1";
			label1.Size = new System.Drawing.Size(109, 19);
			label1.TabIndex = 6;
			label1.Text = "选择线路：";
			linkLabel2.AutoSize = true;
			linkLabel2.Font = new System.Drawing.Font("宋体", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 134);
			linkLabel2.Location = new System.Drawing.Point(211, 157);
			linkLabel2.Name = "linkLabel2";
			linkLabel2.Size = new System.Drawing.Size(93, 16);
			linkLabel2.TabIndex = 5;
			linkLabel2.TabStop = true;
			linkLabel2.Text = "备用服务器";
			linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(linkLabel2_LinkClicked);
			btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			btnClose.Location = new System.Drawing.Point(368, 226);
			btnClose.Name = "btnClose";
			btnClose.Size = new System.Drawing.Size(101, 23);
			btnClose.TabIndex = 7;
			btnClose.Text = "取消";
			btnClose.UseVisualStyleBackColor = true;
			btnClose.Click += new System.EventHandler(btnClose_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			BackColor = System.Drawing.Color.AntiqueWhite;
			base.ClientSize = new System.Drawing.Size(481, 261);
			base.Controls.Add(btnClose);
			base.Controls.Add(label1);
			base.Controls.Add(linkLabel2);
			base.Controls.Add(linkLabel1);
			base.Controls.Add(pictureBox1);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Name = "frmOnline";
			base.ShowInTaskbar = false;
			base.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			Text = "frmOnline";
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(frmOnline_FormClosing);
			base.Load += new System.EventHandler(frmOnline_Load);
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
