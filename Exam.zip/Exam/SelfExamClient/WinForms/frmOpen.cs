using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Net;
using System.Runtime.InteropServices;
using System.Security;
using System.Timers;
using System.Windows.Forms;
using Newtonsoft.Json;
using SelfExamClient.Controls;
using SelfExamClient.Handler;
using SelfExamClient.Utils;

namespace SelfExamClient.WinForms
{
	public class frmOpen : Form
	{
		[Flags]
		private enum MouseEventFlag : uint
		{
			Move = 0x1u,
			LeftDown = 0x2u,
			LeftUp = 0x4u,
			RightDown = 0x8u,
			RightUp = 0x10u,
			MiddleDown = 0x20u,
			MiddleUp = 0x40u,
			XDown = 0x80u,
			XUp = 0x100u,
			Wheel = 0x800u,
			VirtualDesk = 0x4000u,
			Absolute = 0x8000u
		}

		private delegate void SetIPCallBack(Color c, bool bl);

		private delegate void SetTopCallBack(bool bl);

		private delegate void SetPanelCallBack();

		private bool multiThreadedMessageLoopEnabled;

		private string targetUrl;

		private frmMain main;

		private int InputMethodHeight = 45;

		public const int WM_DEVICECHANGE = 537;

		public const int DBT_DEVICEARRIVAL = 32768;

		public const int DBT_CONFIGCHANGECANCELED = 25;

		public const int DBT_CONFIGCHANGED = 24;

		public const int DBT_CUSTOMEVENT = 32774;

		public const int DBT_DEVICEQUERYREMOVE = 32769;

		public const int DBT_DEVICEQUERYREMOVEFAILED = 32770;

		public const int DBT_DEVICEREMOVECOMPLETE = 32772;

		public const int DBT_DEVICEREMOVEPENDING = 32771;

		public const int DBT_DEVICETYPESPECIFIC = 32773;

		public const int DBT_DEVNODES_CHANGED = 7;

		public const int DBT_QUERYCHANGECONFIG = 23;

		public const int DBT_USERDEFINED = 65535;

		private PictureBox picQrode = new PictureBox();

		private Cls_MoveControl MoveControl;

		public const uint WM_SYSCOMMAND = 274u;

		public const int SC_MOVE = 61456;

		public const int HTCAPTION = 2;

		private Label lblip = new Label();

		private string fzjh;

		private DictObject dictObject;

		private ArrayList arrlist = new ArrayList();

		private short[] langIDs;

		private int iFlagInputLan;

		private int CountInterval;

		private PictureBox picip = new PictureBox();

		private Point pt;

		private int IntervalNum;

		private Stack<MsgObject> stk = new Stack<MsgObject>();

		private bool IsClose;

		public bool IsQrcode;

		public bool IsShow = true;

		public System.Timers.Timer myTimer;

		private IContainer components;

		private Panel panel2;

		private System.Windows.Forms.Timer timer1;

		private Label label5;

		private Panel pnlNetStatus;

		private Panel panel1;

		private System.Windows.Forms.Timer timer2;

		private System.Windows.Forms.Timer timer3;

		protected override CreateParams CreateParams
		{
			get
			{
				CreateParams obj = base.CreateParams;
				//obj.ExStyle &= -262145;
				//obj.ExStyle |= 128;
				return obj;
			}
		}

		[DllImport("User32.dll", CharSet = CharSet.Auto)]
		[SuppressUnmanagedCodeSecurity]
		public static extern bool PeekMessage(out Message msg, IntPtr hWnd, uint messageFilterMin, uint messageFilterMax, uint flags);

		[DllImport("User32.dll", CharSet = CharSet.Auto)]
		[SuppressUnmanagedCodeSecurity]
		public static extern bool TranslateMessage(out Message msg);

		[DllImport("User32.dll", CharSet = CharSet.Auto)]
		[SuppressUnmanagedCodeSecurity]
		public static extern bool DispatchMessage(out Message msg);

		[DllImport("User32.DLL")]
		public static extern int SendMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);

		[DllImport("User32.DLL")]
		public static extern bool ReleaseCapture();

		[DllImport("user32.dll")]
		private static extern bool SetCursorPos(int X, int Y);

		[DllImport("user32.dll")]
		private static extern void mouse_event(MouseEventFlag flags, int dx, int dy, uint data, UIntPtr extraInfo);

		public frmOpen(string targUrl, bool _multiThreadedMessageLoopEnabled, frmMain _parentMain)
		{
			InitializeComponent();
			base.WindowState = FormWindowState.Maximized;
			targetUrl = targUrl;
			main = _parentMain;
			base.Load += BrowserFormLoad;
			base.Resize += FrmOpen_Resize;
			multiThreadedMessageLoopEnabled = _multiThreadedMessageLoopEnabled;
			_parentMain.TopMost = false;
			Common.WriteLog(string.Format("......打开窗口：{0}", "打开完成......"));
			HCos.IsExamOpen = true;
			//Common.Protect(base.Handle);
			pnlNetStatus.Visible = false;
			timer1.Enabled = true;
			timer1.Start();
			myTimer = new System.Timers.Timer();
			myTimer.Interval = 1000.0;
			myTimer.Elapsed += MyTimer_Elapsed;
			myTimer.Start();
		}

		private void FrmOpen_Resize(object sender, EventArgs e)
		{
		}

		private void BrowserFormLoad(object sender, EventArgs e)
		{
			BrowserTabUserControl value = new BrowserTabUserControl(targetUrl, multiThreadedMessageLoopEnabled)
			{
				Dock = DockStyle.Fill
			};
			panel2.Controls.Add(value);
			panel1.Visible = false;
			timer2.Interval = HCos.PantInterval * 1000;
			timer2.Enabled = true;
			if (HCos.dictObjects == null)
			{
				DictData();
			}
			else
			{
				dictObject = HCos.dictObjects;
			}
			Point location = new Point(Screen.PrimaryScreen.WorkingArea.Width - 200, Screen.PrimaryScreen.WorkingArea.Height + 10);
			picip.BackColor = HCos.GetPixelColor(location.X, location.Y);
			picip.Location = location;
			picip.SizeMode = PictureBoxSizeMode.AutoSize;
			base.Controls.Add(picip);
			picip.BringToFront();
			picip.Visible = false;
		}

		private void InitInputWin10()
		{
			try
			{
				TSFWapper.GetCurrentLang(out var _);
				langIDs = TSFWapper.GetLangIDs();
				if (langIDs.Length == 0)
				{
					return;
				}
				int num = 0;
				string[] inputMethodList = TSFWapper.GetInputMethodList(langIDs[0]);
				panel1.Height = inputMethodList.Length * InputMethodHeight;
				string[] array = inputMethodList;
				foreach (string text in array)
				{
					AddButton(langIDs[0].ToString(), text, "0", num);
					arrlist.Add(text);
					num++;
				}
				if (langIDs.Length != 1)
				{
					inputMethodList = TSFWapper.GetInputMethodList(langIDs[1]);
					panel1.Height += inputMethodList.Length * InputMethodHeight;
					array = inputMethodList;
					foreach (string text2 in array)
					{
						AddButton(langIDs[1].ToString(), text2, "1", num);
						num++;
						arrlist.Add(text2);
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
				MessageBox.Show(ex.Message);
			}
		}

		private void AddButton(string chnl, string title, string cnum, int i)
		{
			Button button = new Button();
			button.Text = title;
			button.Width = panel1.Width;
			button.Height = InputMethodHeight;
			button.FlatStyle = FlatStyle.Flat;
			button.Tag = $"1,{chnl},{cnum}";
			button.Location = new Point(0, i * InputMethodHeight);
			button.MouseLeave += Lbl_MouseLeave;
			button.Click += Lbl_Click;
			panel1.Controls.Add(button);
		}

		private void Lbl_Click(object sender, EventArgs e)
		{
			try
			{
				SetCursorPos(0, panel1.Location.Y + 400);
				Button button = (Button)sender;
				if (!(button.Tag.ToString() == "0"))
				{
					return;
				}
				for (int i = 0; i < InputLanguage.InstalledInputLanguages.Count; i++)
				{
					if (InputLanguage.CurrentInputLanguage.LayoutName != button.Text)
					{
						mouse_event(MouseEventFlag.LeftDown, 0, 0, 0u, UIntPtr.Zero);
						mouse_event(MouseEventFlag.LeftUp, 0, 0, 0u, UIntPtr.Zero);
						SendKeys.SendWait("^+");
					}
				}
				MessageBox.Show(InputLanguage.CurrentInputLanguage.LayoutName);
			}
			catch (Exception)
			{
			}
		}

		private void Lbl_MouseLeave(object sender, EventArgs e)
		{
			try
			{
				Rectangle rectangle = panel1.RectangleToClient(base.ClientRectangle);
				rectangle.X = -rectangle.X;
				rectangle.Y = -rectangle.Y;
				rectangle.Width = panel1.Width;
				rectangle.Height = panel1.Height;
				if (!rectangle.Contains(Control.MousePosition))
				{
					panel1.Visible = false;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void frmOpen_InputLanguageChanging(object sender, InputLanguageChangingEventArgs e)
		{
			e.Cancel = true;
			try
			{
				int count = InputLanguage.InstalledInputLanguages.Count;
				for (int i = 0; i < InputLanguage.InstalledInputLanguages.Count; i++)
				{
					if (InputLanguage.CurrentInputLanguage.LayoutName == InputLanguage.InstalledInputLanguages[i].LayoutName)
					{
						iFlagInputLan = i;
						break;
					}
				}
				if (iFlagInputLan + 1 >= count)
				{
					iFlagInputLan = 0;
				}
				else
				{
					iFlagInputLan++;
				}
				InputLanguage.CurrentInputLanguage = InputLanguage.InstalledInputLanguages[iFlagInputLan];
			}
			catch
			{
			}
		}

		private void frmOpen_FormClosing(object sender, FormClosingEventArgs e)
		{
			try
			{
				HCos.IsExamOpen = false;
				if (panel2.Controls.Count > 0)
				{
					BrowserTabUserControl obj = (BrowserTabUserControl)panel2.Controls[0];
					obj.Browser.GetBrowser().CloseBrowser(forceClose: false);
					obj.Browser.Dispose();
				}
				if (Environment.OSVersion.Version.Major > 6)
				{
					Dispose(disposing: true);
				}
				if (main != null && myTimer != null)
				{
					myTimer.Enabled = false;
				}
			}
			catch (Exception ex)
			{
				Common.WriteLog($"......*******释放资源异常：{ex.Message}");
			}
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void pictureBox3_Click(object sender, EventArgs e)
		{
			Close();
		}

		private void CloseWindow()
		{
			if (base.InvokeRequired)
			{
				Invoke((MethodInvoker)delegate
				{
					CloseWindow();
				});
			}
			else
			{
				Close();
			}
		}

		public void SaveAndCloseWin(string filePath, string QuestionId, string EditorId)
		{
			try
			{
				string text = "window.alert('error 1000000');";
				string text2 = "";
				if (panel2.Controls.Count > 0)
				{
					BrowserTabUserControl obj = (BrowserTabUserControl)panel2.Controls[0];
					CommonEntity.currentBrowser = obj.Browser.GetBrowser();
					text2 = obj.currentUrl;
				}
				if (text2.IndexOf("exam/single/view") <= 0 && text2.IndexOf(".com/") > 0)
				{
					text2 = text2.Substring(0, text2.IndexOf(".com/") + 4) + "/exam/student/exam/question/attaches/";
					Common.UploadImageToServer(filePath, out var tempName, out var fileName, out var _, text2);
					text = $"webkitCallback_insertHtml('{QuestionId}','{EditorId}','{tempName}','{tempName}','{fileName}')";
					if (CommonEntity.currentBrowser != null)
					{
						CommonEntity.currentBrowser.MainFrame.ExecuteJavaScriptAsync(text);
					}
				}
			}
			catch
			{
			}
		}

		protected override void WndProc(ref Message m)
		{
			try
			{
				if (m.Msg == 537)
				{
					switch (m.WParam.ToInt32())
					{
					case 32768:
						m.Result = (IntPtr)0;
						break;
					case 32772:
						m.Result = (IntPtr)0;
						break;
					}
				}
			}
			catch (Exception)
			{
			}
			base.WndProc(ref m);
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				if (HCos.IsNetStatus)
				{
					if (pnlNetStatus.Visible)
					{
						pictureBox2_Click(sender, e);
					}
					pnlNetStatus.Visible = false;
				}
				else
				{
					pnlNetStatus.BringToFront();
					pnlNetStatus.Visible = true;
				}
			}
			catch
			{
			}
			_ = panel2.Controls.Count;
			_ = 0;
		}

		private void timer2_Tick(object sender, EventArgs e)
		{
			HttpAsyncRequestHelper.HttpAsyncRequest($"{HCos.Domain}{HCos.MessageUrl2}?examLogicId={HCos.examLogicId}&token={HCos.Token}", "get", CallBackFuc, new ObjectMessage());
			HttpAsyncRequestHelper.HttpAsyncRequest($"{HCos.Domain}{HCos.MessageUrl}?examUid={HCos.examUID}&examLogicId={HCos.examLogicId}", "get", CallBackFuc, new ServerMessageObject());
		}

		private void SetPanel()
		{
			if (panel1.InvokeRequired)
			{
				SetPanelCallBack method = SetPanel;
				Invoke(method, null);
			}
			else
			{
				panel1.Visible = true;
			}
		}

		public void SetInputMethod()
		{
			SetPanel();
		}

		private void SetTM(bool bl)
		{
			if (base.InvokeRequired)
			{
				SetTopCallBack method = SetTM;
				Invoke(method, bl);
			}
			else
			{
				base.TopMost = true;
			}
		}

		public void SetTopMost(bool bl)
		{
			SetTM(bl);
		}

		public void SetTMIP(Color c, bool bl)
		{
		}

		private void panel1_MouseLeave(object sender, EventArgs e)
		{
		}

		private void panel2_MouseMove(object sender, MouseEventArgs e)
		{
		}

		private void frmOpen_MouseMove(object sender, MouseEventArgs e)
		{
		}

		private void pictureBox2_Click(object sender, EventArgs e)
		{
		}

		private void pictureBox2_Click_1(object sender, EventArgs e)
		{
		}

		private void panel3_MouseDown(object sender, MouseEventArgs e)
		{
			pt = Cursor.Position;
		}

		private void panel3_MouseMove(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				_ = Cursor.Position.X;
				_ = pt.X;
				_ = Cursor.Position.Y;
				_ = pt.Y;
				pt = Cursor.Position;
			}
		}

		private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
		{
			ReleaseCapture();
		}

		private void DictData()
		{
			HttpAsyncRequestHelper.HttpAsyncRequest(HCos.Domain + HCos.DictPath, "get", CallBackFuc, new DictObject());
		}

		private string SelectDictText(string val)
		{
			if (dictObject == null || dictObject.data == null)
			{
				DictData();
				return "";
			}
			DictItem dictItem = dictObject.data.Find((DictItem o) => o.dictValue == val);
			if (dictItem != null)
			{
				return dictItem.dictLabel;
			}
			return "";
		}

		private void CallBackFuc(object obj, string respStr, int statusCode, WebException e)
		{
			if (statusCode == 200)
			{
				if (obj.GetType().Name == "ServerMessageObject")
				{
					ServerMessageObject smObj = JsonConvert.DeserializeObject<ServerMessageObject>(respStr);
					ShowMessage(smObj);
				}
				else if (obj.GetType().Name == "DictObject")
				{
					dictObject = JsonConvert.DeserializeObject<DictObject>(respStr);
				}
				else if (obj.GetType().Name == "ObjectMessage")
				{
					ObjectMessage msgObject = JsonConvert.DeserializeObject<ObjectMessage>(respStr);
					ShowMessageInside(msgObject);
				}
				else
				{
					ServerMessageObject smObj2 = JsonConvert.DeserializeObject<ServerMessageObject>(respStr);
					ShowQrcode(smObj2);
				}
			}
		}

		private void ShowMessage(ServerMessageObject smObj)
		{
			if (smObj == null || smObj.data == null)
			{
				return;
			}
			string text = "";
			if (smObj.data.submitStatus != "0")
			{
				MsgObject msgObject = new MsgObject();
				msgObject.MsgType = "2";
				msgObject.Message = "已强制交卷！";
				stk.Push(msgObject);
			}
			for (int i = 0; i < smObj.data.msgList.Count; i++)
			{
				text = smObj.data.msgList[i].msgContent;
				if (!(text == ""))
				{
					MsgObject msgObject = new MsgObject();
					msgObject.MsgType = "1";
					msgObject.Message = text;
					stk.Push(msgObject);
				}
			}
			_ = smObj.data.sideStatus != "1";
		}

		private void ShowMessageInside(ObjectMessage msgObject)
		{
			if (msgObject != null && msgObject != null && !(msgObject.message.ToString() == "false") && msgObject.data != "1")
			{
				MsgObject msgObject2 = new MsgObject();
				msgObject2.MsgType = "3";
				msgObject2.Message = "监控APP断开，请重新扫描监控二维码！";
				stk.Push(msgObject2);
			}
		}

		private void AddCtrl(string message, int bottomPosition)
		{
			if (message == "")
			{
				return;
			}
			if (base.InvokeRequired)
			{
				Invoke((MethodInvoker)delegate
				{
					AddCtrl(message, bottomPosition);
				});
				return;
			}
			PopLayerT popLayerT = new PopLayerT();
			popLayerT.Height = 45;
			popLayerT.Width = 520;
			popLayerT.BackColor = Color.FromArgb(255, 242, 222);
			popLayerT.ForeColor = Color.FromArgb(255, 153, 0);
			popLayerT.BorderColor = Color.FromArgb(255, 153, 0);
			popLayerT.Font = new Font("微软雅黑", 12f, FontStyle.Bold);
			popLayerT.Alpha = 255;
			popLayerT.Text = message;
			popLayerT.BottomHeight = bottomPosition;
			base.Controls.Add(popLayerT);
			popLayerT.ShowMask();
		}

		private void ShowCloseLayer(string message)
		{
			if (message == "")
			{
				return;
			}
			if (base.InvokeRequired)
			{
				Invoke((MethodInvoker)delegate
				{
					ShowCloseLayer(message);
				});
				return;
			}
			MaskLayer maskLayer = new MaskLayer();
			maskLayer.EnabledClickHide = true;
			maskLayer.Text = message;
			base.Controls.Add(maskLayer);
			maskLayer.IsClose = true;
			maskLayer.ShowMask();
		}

		private void AddMaskLayer(string message)
		{
			if (message == "")
			{
				return;
			}
			if (base.InvokeRequired)
			{
				Invoke((MethodInvoker)delegate
				{
					AddMaskLayer(message);
				});
				return;
			}
			MaskLayer maskLayer = new MaskLayer();
			maskLayer.EnabledClickHide = true;
			maskLayer.Text = message;
			base.Controls.Add(maskLayer);
			maskLayer.IsClose = false;
			maskLayer.ShowMask();
		}

		private void ShowMask(string message)
		{
			PopMask popMask = new PopMask();
			popMask.Message = message;
			popMask.Show();
		}

		private void timer3_Tick(object sender, EventArgs e)
		{
			if (stk.Count <= 0)
			{
				return;
			}
			timer3.Stop();
			MsgObject msgObject = stk.Pop();
			PopMask popMask = new PopMask();
			popMask.Message = msgObject.Message;
			if (msgObject.MsgType == "2")
			{
				if (!IsClose)
				{
					IsClose = true;
					popMask.ShowDialog();
				}
				CloseWindow();
			}
			else if (msgObject.MsgType == "3")
			{
				if (!IsQrcode)
				{
					if (!IsShow)
					{
						IsShow = true;
						return;
					}
					IsQrcode = true;
					timer3.Start();
					ShowQrcode();
				}
			}
			else
			{
				popMask.ShowDialog();
				timer3.Start();
			}
		}

		private void MyTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (stk.Count <= 0)
			{
				return;
			}
			MsgObject msgObject = stk.Pop();
			PopMask popMask = new PopMask();
			popMask.Message = msgObject.Message;
			if (msgObject.MsgType == "2")
			{
				myTimer.Enabled = false;
				if (!IsClose)
				{
					IsClose = true;
					popMask.ShowDialog();
				}
				CloseWindow();
			}
			else if (msgObject.MsgType == "3")
			{
				if (!IsQrcode)
				{
					if (!IsShow)
					{
						IsShow = true;
						return;
					}
					IsQrcode = true;
					ShowQrcode();
				}
			}
			else
			{
				myTimer.Enabled = false;
				popMask.ShowDialog();
				myTimer.Enabled = true;
			}
		}

		public void ReviewT()
		{
			IsQrcode = false;
			IsShow = false;
		}

		private void ShowQrcode()
		{
			HttpAsyncRequestHelper.HttpAsyncRequest($"{HCos.Domain}{HCos.MessageUrl}?examUid={HCos.examUID}&examLogicId={HCos.examLogicId}", "get", CallBackFuc, new object());
		}

		private void ShowQrcode(ServerMessageObject smObj)
		{
			if (smObj.data.sideStatus != "1")
			{
				PopMaskQ popMaskQ = new PopMaskQ();
				popMaskQ.SetParent = this;
				popMaskQ.ShowDialog();
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SelfExamClient.WinForms.frmOpen));
			panel2 = new System.Windows.Forms.Panel();
			panel1 = new System.Windows.Forms.Panel();
			timer1 = new System.Windows.Forms.Timer(components);
			label5 = new System.Windows.Forms.Label();
			pnlNetStatus = new System.Windows.Forms.Panel();
			timer2 = new System.Windows.Forms.Timer(components);
			timer3 = new System.Windows.Forms.Timer(components);
			pnlNetStatus.SuspendLayout();
			SuspendLayout();
			panel2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
			panel2.Location = new System.Drawing.Point(0, 0);
			panel2.Name = "panel2";
			panel2.Size = new System.Drawing.Size(1138, 652);
			panel2.TabIndex = 1;
			panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(panel2_MouseMove);
			panel1.BackColor = System.Drawing.SystemColors.ControlLight;
			panel1.Location = new System.Drawing.Point(35, 131);
			panel1.Name = "panel1";
			panel1.Size = new System.Drawing.Size(200, 100);
			panel1.TabIndex = 0;
			panel1.MouseLeave += new System.EventHandler(panel1_MouseLeave);
			timer1.Tick += new System.EventHandler(timer1_Tick);
			label5.AutoSize = true;
			label5.Font = new System.Drawing.Font("宋体", 14.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 134);
			label5.ForeColor = System.Drawing.Color.Red;
			label5.Location = new System.Drawing.Point(3, 15);
			label5.Name = "label5";
			label5.Size = new System.Drawing.Size(415, 19);
			label5.TabIndex = 0;
			label5.Text = "网络断开，正在检测网络状态，请稍后......";
			pnlNetStatus.Controls.Add(label5);
			pnlNetStatus.Location = new System.Drawing.Point(389, 210);
			pnlNetStatus.Name = "pnlNetStatus";
			pnlNetStatus.Size = new System.Drawing.Size(428, 47);
			pnlNetStatus.TabIndex = 0;
			timer2.Interval = 20000;
			timer2.Tick += new System.EventHandler(timer2_Tick);
			timer3.Interval = 500;
			timer3.Tick += new System.EventHandler(timer3_Tick);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(1138, 652);
			base.Controls.Add(panel1);
			base.Controls.Add(pnlNetStatus);
			base.Controls.Add(panel2);
			base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			base.Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
			base.ImeMode = System.Windows.Forms.ImeMode.Disable;
			base.Name = "frmOpen";
			Text = "考试平台";
			base.FormClosing += new System.Windows.Forms.FormClosingEventHandler(frmOpen_FormClosing);
			base.InputLanguageChanging += new System.Windows.Forms.InputLanguageChangingEventHandler(frmOpen_InputLanguageChanging);
			base.MouseMove += new System.Windows.Forms.MouseEventHandler(frmOpen_MouseMove);
			pnlNetStatus.ResumeLayout(false);
			pnlNetStatus.PerformLayout();
			ResumeLayout(false);
		}
	}
}
