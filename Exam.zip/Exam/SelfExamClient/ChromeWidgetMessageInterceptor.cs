using System;
using System.Windows.Forms;

namespace SelfExamClient
{
	internal class ChromeWidgetMessageInterceptor : NativeWindow
	{
		private Action<Message> forwardAction;

		internal ChromeWidgetMessageInterceptor(Control browser, IntPtr chromeWidgetHostHandle, Action<Message> forwardAction)
		{
			AssignHandle(chromeWidgetHostHandle);
			browser.HandleDestroyed += BrowserHandleDestroyed;
			this.forwardAction = forwardAction;
		}

		private void BrowserHandleDestroyed(object sender, EventArgs e)
		{
			ReleaseHandle();
			((Control)sender).HandleDestroyed -= BrowserHandleDestroyed;
			forwardAction = null;
		}

		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			if (forwardAction != null)
			{
				forwardAction(m);
			}
		}
	}
}
