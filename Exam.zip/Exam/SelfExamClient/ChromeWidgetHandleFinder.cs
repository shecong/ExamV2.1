using System;
using System.Runtime.InteropServices;
using System.Text;

namespace SelfExamClient
{
	internal static class ChromeWidgetHandleFinder
	{
		private delegate bool EnumWindowProc(IntPtr hwnd, IntPtr lParam);

		private class ClassDetails
		{
			public IntPtr DescendantFound { get; set; }
		}

		[DllImport("user32")]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool EnumChildWindows(IntPtr window, EnumWindowProc callback, IntPtr lParam);

		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

		private static bool EnumWindow(IntPtr hWnd, IntPtr lParam)
		{
			StringBuilder stringBuilder = new StringBuilder(128);
			GetClassName(hWnd, stringBuilder, stringBuilder.Capacity);
			if (stringBuilder.ToString() == "Chrome_RenderWidgetHostHWND")
			{
				((ClassDetails)GCHandle.FromIntPtr(lParam).Target).DescendantFound = hWnd;
				return false;
			}
			return true;
		}

		public static bool TryFindHandle(IntPtr browserHandle, out IntPtr chromeWidgetHostHandle)
		{
			ClassDetails classDetails = new ClassDetails();
			GCHandle value = GCHandle.Alloc(classDetails);
			EnumWindowProc callback = EnumWindow;
			EnumChildWindows(browserHandle, callback, GCHandle.ToIntPtr(value));
			chromeWidgetHostHandle = classDetails.DescendantFound;
			value.Free();
			return classDetails.DescendantFound != IntPtr.Zero;
		}
	}
}
