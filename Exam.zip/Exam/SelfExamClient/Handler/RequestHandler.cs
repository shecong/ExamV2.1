using System;
using System.Collections.Generic;
using System.Text;
using CefSharp;
using SelfExamClient.Filters;

namespace SelfExamClient.Handler
{
	public class RequestHandler : DefaultRequestHandler
	{
		public static readonly string VersionNumberString = $"Chromium: {Cef.ChromiumVersion}, CEF: {Cef.CefVersion}, CefSharp: {Cef.CefSharpVersion}";

		private Dictionary<ulong, MemoryStreamResponseFilter> responseDictionary = new Dictionary<ulong, MemoryStreamResponseFilter>();

		public override bool OnBeforeBrowse(IWebBrowser browserControl, IBrowser browser, IFrame frame, IRequest request, bool isRedirect)
		{
			return false;
		}

		public override bool OnOpenUrlFromTab(IWebBrowser browserControl, IBrowser browser, IFrame frame, string targetUrl, WindowOpenDisposition targetDisposition, bool userGesture)
		{
			return false;
		}

		public override bool OnCertificateError(IWebBrowser browserControl, IBrowser browser, CefErrorCode errorCode, string requestUrl, ISslInfo sslInfo, IRequestCallback callback)
		{
			if (!callback.IsDisposed)
			{
				using (callback)
				{
				}
			}
			return false;
		}

		public override void OnPluginCrashed(IWebBrowser browserControl, IBrowser browser, string pluginPath)
		{
		}

		public override CefReturnValue OnBeforeResourceLoad(IWebBrowser browserControl, IBrowser browser, IFrame frame, IRequest request, IRequestCallback callback)
		{
			if (!Uri.TryCreate(request.Url, UriKind.Absolute, out var result))
			{
				return CefReturnValue.Cancel;
			}
			if (result.Scheme == "custom")
			{
				request.SetReferrer("http://jk.edu-edu.com/examinee", ReferrerPolicy.ClearReferrerOnTransitionFromSecureToInsecure);
			}
			if (!callback.IsDisposed)
			{
				using (callback)
				{
					if (request.Method == "POST")
					{
						using IPostData postData = request.PostData;
						if (postData != null)
						{
							IList<IPostDataElement> elements = postData.Elements;
							string charSet = request.GetCharSet();
							foreach (IPostDataElement item in elements)
							{
								if (item.Type == PostDataElementType.Bytes)
								{
									item.GetBody(charSet);
								}
							}
						}
					}
				}
			}
			return CefReturnValue.Continue;
		}

		public override bool GetAuthCredentials(IWebBrowser browserControl, IBrowser browser, IFrame frame, bool isProxy, string host, int port, string realm, string scheme, IAuthCallback callback)
		{
			callback.Dispose();
			return false;
		}

		public override void OnRenderProcessTerminated(IWebBrowser browserControl, IBrowser browser, CefTerminationStatus status)
		{
		}

		public override bool OnQuotaRequest(IWebBrowser browserControl, IBrowser browser, string originUrl, long newSize, IRequestCallback callback)
		{
			if (!callback.IsDisposed)
			{
				using (callback)
				{
				}
			}
			return false;
		}

		public override void OnResourceRedirect(IWebBrowser browserControl, IBrowser browser, IFrame frame, IRequest request, ref string newUrl)
		{
		}

		public override bool OnProtocolExecution(IWebBrowser browserControl, IBrowser browser, string url)
		{
			return url.StartsWith("mailto");
		}

		public override void OnRenderViewReady(IWebBrowser browserControl, IBrowser browser)
		{
		}

		public override bool OnResourceResponse(IWebBrowser browserControl, IBrowser browser, IFrame frame, IRequest request, IResponse response)
		{
			return false;
		}

		public override IResponseFilter GetResourceResponseFilter(IWebBrowser browserControl, IBrowser browser, IFrame frame, IRequest request, IResponse response)
		{
			if (new Uri(request.Url).Scheme == "custom")
			{
				MemoryStreamResponseFilter memoryStreamResponseFilter = new MemoryStreamResponseFilter();
				responseDictionary.Add(request.Identifier, memoryStreamResponseFilter);
				return memoryStreamResponseFilter;
			}
			return null;
		}

		public override void OnResourceLoadComplete(IWebBrowser browserControl, IBrowser browser, IFrame frame, IRequest request, IResponse response, UrlRequestStatus status, long receivedContentLength)
		{
			if (new Uri(request.Url).Scheme == "custom" && responseDictionary.TryGetValue(request.Identifier, out var value))
			{
				byte[] data = value.Data;
				_ = value.Data.Length;
				Encoding.UTF8.GetString(data);
			}
		}
	}
}
