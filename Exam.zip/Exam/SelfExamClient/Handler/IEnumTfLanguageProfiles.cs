using System.Runtime.InteropServices;

namespace SelfExamClient.Handler
{
	[ComImport]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("3d61bf11-ac5f-42c8-a4cb-931bcc28c744")]
	internal interface IEnumTfLanguageProfiles
	{
		void Clone(out IEnumTfLanguageProfiles enumIPP);

		[PreserveSig]
		int Next(int count, [Out][MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 2)] TF_LANGUAGEPROFILE[] profiles, out int fetched);

		void Reset();

		void Skip(int count);
	}
}
