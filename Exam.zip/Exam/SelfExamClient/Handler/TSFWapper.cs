using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace SelfExamClient.Handler
{
	public class TSFWapper
	{
		public static short[] GetLangIDs()
		{
			List<short> list = new List<short>();
			if (TSF_NativeAPI.TF_CreateInputProcessorProfiles(out var profiles) == 0)
			{
				int count = 0;
				if (profiles.GetLanguageList(out var langids, out count) == 0)
				{
					for (int i = 0; i < count; i++)
					{
						short item = Marshal.ReadInt16(langids, 2 * i);
						list.Add(item);
					}
				}
				Marshal.ReleaseComObject(profiles);
			}
			return list.ToArray();
		}

		public static string[] GetInputMethodList(short langID)
		{
			List<string> list = new List<string>();
			if (TSF_NativeAPI.TF_CreateInputProcessorProfiles(out var profiles) == 0)
			{
				try
				{
					IEnumTfLanguageProfiles enumIPP = null;
					if (profiles.EnumLanguageProfiles(langID, out enumIPP) == 0 && enumIPP != null)
					{
						TF_LANGUAGEPROFILE[] array = new TF_LANGUAGEPROFILE[1];
						int fetched = 0;
						while (enumIPP.Next(1, array, out fetched) == 0)
						{
							if (profiles.GetLanguageProfileDescription(ref array[0].clsid, array[0].langid, ref array[0].guidProfile, out var desc) == 0 && profiles.IsEnabledLanguageProfile(ref array[0].clsid, array[0].langid, ref array[0].guidProfile, out var enabled) == 0 && enabled)
							{
								list.Add(Marshal.PtrToStringBSTR(desc));
							}
							Marshal.FreeBSTR(desc);
						}
					}
				}
				finally
				{
					Marshal.ReleaseComObject(profiles);
				}
			}
			return list.ToArray();
		}

		public static void GetCurrentLang(out string[] lang)
		{
			new List<short>();
			short langid = -1;
			if (TSF_NativeAPI.TF_CreateInputProcessorProfiles(out var profiles) == 0)
			{
				profiles.GetCurrentLanguage(out langid);
				Marshal.ReleaseComObject(profiles);
			}
			lang = ((langid > -1) ? GetInputMethodList(langid) : null);
		}

		public static bool ActiveInputMethodWithDesc(short langID, string desc, int _index)
		{
			if (TSF_NativeAPI.TF_CreateInputProcessorProfiles(out var profiles) == 0)
			{
				try
				{
					IEnumTfLanguageProfiles enumIPP = null;
					if (profiles.EnumLanguageProfiles(langID, out enumIPP) == 0 && enumIPP != null)
					{
						TF_LANGUAGEPROFILE[] array = new TF_LANGUAGEPROFILE[1];
						int fetched = 0;
						while (enumIPP.Next(1, array, out fetched) == 0)
						{
							if (profiles.GetLanguageProfileDescription(ref array[0].clsid, array[0].langid, ref array[0].guidProfile, out var desc2) == 0)
							{
								if (profiles.IsEnabledLanguageProfile(ref array[0].clsid, array[0].langid, ref array[0].guidProfile, out var enabled) == 0 && enabled && Marshal.PtrToStringBSTR(desc2).Equals(desc))
								{
									return profiles.ActivateLanguageProfile(ref array[0].clsid, array[0].langid, ref array[0].guidProfile) == 0;
								}
								Marshal.FreeBSTR(desc2);
							}
						}
					}
				}
				finally
				{
					Marshal.ReleaseComObject(profiles);
				}
			}
			return false;
		}
	}
}
