using System;
using System.Runtime.InteropServices;
using System.Security;

namespace SelfExamClient.Handler
{
	internal static class TSF_NativeAPI
	{
		public static readonly Guid GUID_TFCAT_TIP_KEYBOARD;

		static TSF_NativeAPI()
		{
			GUID_TFCAT_TIP_KEYBOARD = new Guid(880041059u, 45808, 18308, 139, 103, 94, 18, 200, 112, 26, 49);
		}

		[DllImport("msctf.dll")]
		[SecurityCritical]
		[SuppressUnmanagedCodeSecurity]
		public static extern int TF_CreateInputProcessorProfiles(out ITfInputProcessorProfiles profiles);
	}
}
