using System;
using System.Windows.Forms;
using CefSharp;

namespace SelfExamClient.Handler
{
	public class WinFormsRequestHandler : RequestHandler
	{
		private Action<string, int?> openNewTab;

		public WinFormsRequestHandler(Action<string, int?> openNewTab)
		{
			this.openNewTab = openNewTab;
		}

		public override bool OnOpenUrlFromTab(IWebBrowser browserControl, IBrowser browser, IFrame frame, string targetUrl, WindowOpenDisposition targetDisposition, bool userGesture)
		{
			if (openNewTab == null)
			{
				return false;
			}
			_ = (Control)browserControl;
			return true;
		}
	}
}
