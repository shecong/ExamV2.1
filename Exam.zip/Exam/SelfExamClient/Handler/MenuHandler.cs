using CefSharp;

namespace SelfExamClient.Handler
{
	public class MenuHandler : IContextMenuHandler
	{
		private const int ShowDevTools = 26501;

		private const int CloseDevTools = 26502;

		void IContextMenuHandler.OnBeforeContextMenu(IWebBrowser browserControl, IBrowser browser, IFrame frame, IContextMenuParams parameters, IMenuModel model)
		{
			model.Clear();
			model.AddItem(CefMenuCommand.Reload, "刷新");
		}

		bool IContextMenuHandler.OnContextMenuCommand(IWebBrowser browserControl, IBrowser browser, IFrame frame, IContextMenuParams parameters, CefMenuCommand commandId, CefEventFlags eventFlags)
		{
			if (commandId == (CefMenuCommand)26501)
			{
				browser.ShowDevTools();
			}
			if (commandId == (CefMenuCommand)26502)
			{
				browser.CloseDevTools();
			}
			return false;
		}

		void IContextMenuHandler.OnContextMenuDismissed(IWebBrowser browserControl, IBrowser browser, IFrame frame)
		{
		}

		bool IContextMenuHandler.RunContextMenu(IWebBrowser browserControl, IBrowser browser, IFrame frame, IContextMenuParams parameters, IMenuModel model, IRunContextMenuCallback callback)
		{
			return false;
		}
	}
}
