using System;
using System.Runtime.InteropServices;

namespace SelfExamClient.Handler
{
	internal struct TF_LANGUAGEPROFILE
	{
		internal Guid clsid;

		internal short langid;

		internal Guid catid;

		[MarshalAs(UnmanagedType.Bool)]
		internal bool fActive;

		internal Guid guidProfile;
	}
}
