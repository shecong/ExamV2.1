#define TRACE
using System;
using System.Diagnostics;
using System.Windows.Forms;
using CefSharp;

namespace SelfExamClient.Handler
{
	public class KeyboardHandler : IKeyboardHandler
	{
		public bool OnPreKeyEvent(IWebBrowser browserControl, IBrowser browser, KeyType type, int windowsKeyCode, int nativeKeyCode, CefEventFlags modifiers, bool isSystemKey, ref bool isKeyboardShortcut)
		{
			isKeyboardShortcut = false;
			if (windowsKeyCode == 9 || windowsKeyCode == 37 || windowsKeyCode == 38 || windowsKeyCode == 40 || windowsKeyCode == 39 || windowsKeyCode == 91)
			{
				return false;
			}
			bool result = false;
			Control control = browserControl as Control;
			int msgType = 0;
			switch (type)
			{
			case KeyType.RawKeyDown:
				if (isSystemKey)
				{
					msgType = 260;
				}
				else
				{
					msgType = 256;
				}
				break;
			case KeyType.KeyUp:
				if (isSystemKey)
				{
					msgType = 261;
				}
				else
				{
					msgType = 257;
				}
				break;
			case KeyType.Char:
				if (isSystemKey)
				{
					msgType = 262;
				}
				else
				{
					msgType = 258;
				}
				break;
			default:
				Trace.Assert(condition: false);
				break;
			}
			PreProcessControlState state = PreProcessControlState.MessageNotNeeded;
			control.Invoke((Action)delegate
			{
				Message message = default(Message);
				message.HWnd = control.Handle;
				message.Msg = msgType;
				message.WParam = new IntPtr(windowsKeyCode);
				message.LParam = new IntPtr(nativeKeyCode);
				Message message2 = message;
				if (Application.FilterMessage(ref message2))
				{
					state = PreProcessControlState.MessageProcessed;
				}
				else
				{
					state = control.PreProcessControlMessage(ref message2);
				}
			});
			if (state == PreProcessControlState.MessageNeeded)
			{
				isKeyboardShortcut = true;
			}
			else if (state == PreProcessControlState.MessageProcessed)
			{
				result = true;
			}
			return result;
		}

		public bool OnKeyEvent(IWebBrowser browserControl, IBrowser browser, KeyType type, int windowsKeyCode, int nativeKeyCode, CefEventFlags modifiers, bool isSystemKey)
		{
			return false;
		}
	}
}
