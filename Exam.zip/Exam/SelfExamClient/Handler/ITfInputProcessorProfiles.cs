using System;
using System.Runtime.InteropServices;
using System.Security;

namespace SelfExamClient.Handler
{
	[ComImport]
	[SecurityCritical]
	[SuppressUnmanagedCodeSecurity]
	[Guid("1F02B6C5-7842-4EE6-8A0B-9A24183A95CA")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	internal interface ITfInputProcessorProfiles
	{
		[SecurityCritical]
		void Register();

		[SecurityCritical]
		void Unregister();

		[SecurityCritical]
		void AddLanguageProfile();

		[SecurityCritical]
		void RemoveLanguageProfile();

		[SecurityCritical]
		void EnumInputProcessorInfo();

		[SecurityCritical]
		int GetDefaultLanguageProfile(short langid, ref Guid catid, out Guid clsid, out Guid profile);

		[SecurityCritical]
		void SetDefaultLanguageProfile();

		[SecurityCritical]
		int ActivateLanguageProfile(ref Guid clsid, short langid, ref Guid guidProfile);

		[PreserveSig]
		[SecurityCritical]
		int GetActiveLanguageProfile(ref Guid clsid, out short langid, out Guid profile);

		[SecurityCritical]
		int GetLanguageProfileDescription(ref Guid clsid, short langid, ref Guid profile, out IntPtr desc);

		[SecurityCritical]
		void GetCurrentLanguage(out short langid);

		[PreserveSig]
		[SecurityCritical]
		int ChangeCurrentLanguage(short langid);

		[PreserveSig]
		[SecurityCritical]
		int GetLanguageList(out IntPtr langids, out int count);

		[SecurityCritical]
		int EnumLanguageProfiles(short langid, out IEnumTfLanguageProfiles enumIPP);

		[SecurityCritical]
		int EnableLanguageProfile();

		[SecurityCritical]
		int IsEnabledLanguageProfile(ref Guid clsid, short langid, ref Guid profile, out bool enabled);

		[SecurityCritical]
		void EnableLanguageProfileByDefault();

		[SecurityCritical]
		void SubstituteKeyboardLayout();
	}
}
