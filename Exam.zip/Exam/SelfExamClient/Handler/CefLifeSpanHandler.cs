using System;
using System.Drawing;
using System.Windows.Forms;
using CefSharp;
using CefSharp.WinForms;
using SelfExamClient.Controls;
using SelfExamClient.Utils;
using SelfExamClient.WinForms;

namespace SelfExamClient.Handler
{
	public class CefLifeSpanHandler : ILifeSpanHandler
	{
		public bool DoClose(IWebBrowser browserControl, IBrowser browser)
		{
			if (browser.IsDisposed || browser.IsPopup)
			{
				return false;
			}
			IntPtr windowHandle = browser.GetHost().GetWindowHandle();
			ChromiumWebBrowser chromiumWebBrowser = (ChromiumWebBrowser)browserControl;
			if (!chromiumWebBrowser.IsDisposed && chromiumWebBrowser.IsHandleCreated)
			{
				try
				{
					chromiumWebBrowser.Invoke((Action)delegate
					{
						if (chromiumWebBrowser.FindForm() is MainForm)
						{
							((MainForm)chromiumWebBrowser.FindForm()).RemoveTab(windowHandle);
						}
						else
						{
							_ = chromiumWebBrowser.FindForm() is frmOpen;
						}
					});
				}
				catch
				{
				}
			}
			return false;
		}

		public void OnAfterCreated(IWebBrowser browserControl, IBrowser browser)
		{
		}

		public void OnBeforeClose(IWebBrowser browserControl, IBrowser browser)
		{
		}

		public bool OnBeforePopup(IWebBrowser browserControl, IBrowser browser, IFrame frame, string targetUrl, string targetFrameName, WindowOpenDisposition targetDisposition, bool userGesture, IPopupFeatures popupFeatures, IWindowInfo windowInfo, IBrowserSettings browserSettings, ref bool noJavascriptAccess, out IWebBrowser newBrowser)
		{
			newBrowser = null;
			ChromiumWebBrowser chromiumWebBrowser = (ChromiumWebBrowser)browserControl;
			string str_curr_url = chromiumWebBrowser.Address.ToLower();
			chromiumWebBrowser.Invoke((Action)delegate
			{
				if (chromiumWebBrowser.FindForm() is frmMain)
				{
					frmMain frmMain = (frmMain)chromiumWebBrowser.FindForm();
					frmMain.TopMost = false;
					if (str_curr_url.IndexOf("loginform") > 0 || targetUrl.ToLower().IndexOf("userguide") > 0)
					{
						Common.WriteLog(string.Format("......打开窗口：{0}", "正在打开......"));
						frmSample frmSample = new frmSample(targetUrl, _multiThreadedMessageLoopEnabled: true, frmMain);
						frmSample.WindowState = FormWindowState.Maximized;
						frmSample.TopMost = true;
						frmSample.Show();
					}
					else
					{
						Common.WriteLog(string.Format("......打开窗口：{0}", "正在打开......"));
						frmOpen frmOpen = (HCos.currentOpen = new frmOpen(targetUrl, _multiThreadedMessageLoopEnabled: true, frmMain));
						HCos.currentMain.StopTimer();
						frmOpen.Show();
					}
				}
				else
				{
					chromiumWebBrowser.Load(targetUrl);
				}
			});
			newBrowser = null;
			return true;
		}

		public void myAction(ChromiumWebBrowser chromiumWebBrowser, string targetUrl, IWindowInfo windowInfo)
		{
			if (chromiumWebBrowser.FindForm() is MainForm)
			{
				MainForm obj = (MainForm)chromiumWebBrowser.FindForm();
				BrowserTabUserControl browserTabUserControl = new BrowserTabUserControl(targetUrl, multiThreadedMessageLoopEnabled: true)
				{
					Dock = DockStyle.Fill
				};
				obj.AddTab(browserTabUserControl, targetUrl);
				Rectangle clientRectangle = browserTabUserControl.ClientRectangle;
				windowInfo.SetAsChild(browserTabUserControl.Handle, clientRectangle.Left, clientRectangle.Top, clientRectangle.Right, clientRectangle.Bottom);
			}
		}
	}
}
