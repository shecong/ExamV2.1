namespace SelfExamClient
{
	public class JsonObject
	{
		public string status;

		public string data;

		public string message;
	}
}
