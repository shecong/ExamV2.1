using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using SelfExamClient.Utils;
using SelfExamClient.WinForms;

namespace SelfExamClient
{
	public static class HCos
	{
		private struct POINT
		{
			private int x;

			private int y;
		}

		public static bool IsOpen = false;

		public static bool IsOpenOnline = false;

		public static string PassUrl = "/clientClosePassword?password=";

		public static string MessageUrl = "/api/visitor/customer/getMessageAndSideStatus";

		public static string MessageUrl2 = "/api/pcapi/exam/getMonitorStatus";

		public static string DictPath = "/api/visitor/customer/getTabStatusDict";

		public static string errUrl = "";

		public static string IpUrl = "/ip";

		public static string SUrl = "";

		public static string Domain = "";

		public static string DomainOne = "";

		public static string DomainTwo = "";

		public static string KeyFlag;

		public static string IP = "";

		public static string isHideAll = "0";

		public static bool IsErrorState = false;

		public static bool IsExamOpen = false;

		public static bool IsNetStatus = true;

		public static bool IsWritingOpen = false;

		public static bool IsHotKey = false;

		public static bool IsCalcOpen = false;

		public static bool IsReload = false;

		public static frmMain currentMain;

		public static frmOpen currentOpen;

		public static Dictionary<IntPtr, Window> dictWnd = new Dictionary<IntPtr, Window>();

		public static string examUID = "";

		public static string examLogicId = "";

		public static string Token = "";

		public static Image QrodeImage = null;

		public static string Base64Qrode = "data:image/PNG;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAEsCAYAAAB5fY51AAARU0lEQVR42u3d25LbRhIEUP3/T9vvjnBouiqzwQFPRvhBu6MRCQIHrEJf/vwjIvJL8schEBFgiYgAS0SAJSICLBERYIkIsEREgCUiAiwRAZaICLBERIAlIsASEQGWiAiwRARYIiLAEhEBlogAS0QEWCIiwBIRYImIAEtEBFgiAiwREWCJiABLRIAlIgIsEQGWiAiwRESAJSLAEhEBlogIsEQEWCIiwBIRAZaIAEtEBFgiIsASEWCJiABLRARYIgKsD3nRf/6M/vvv35/+vv/7Paev/6fvr3Wc/va6pj/3t+O1/Tza58NPP7fb7691PQALWMACFrCANYPipyfM6QnVhiD972x/zy3ATn/vT8GfgrL93E7hOb1xba8HYAELWMACFrB2AG1P9OmFP/1KnippUkC2Xk/7eJ6eD9OWwRSGdMnYamUAC1jAAhawgJVtjm9LwvT7Sr2fVCmSKonTME3fd7qEOn1d6eY/sIAFLGABC1h3wbpdGk5LjFTJ12r+n8KeavJPh4dsH/unHtKk3w+wgAUsYAELWFmwUl+ht8BsH4/f+nupC2dbAk1LtdTf/xQY0sMn0tcPsIAFLGAB69vASk/N8Wd//s1/NjUHWP7sz8AC1meBN22ubkGd/v028NuSIj0cojXJ/amSMDU5/yuvXWABC1jAAtYHlIjbpmuqiZ8Grd3ETT98mJY2P4WmNTyj1bRPP7yZwg8sYAELWMACVhe67Vf49Il1WhqmllnZlmKp0qj1mD41/CA9jGVawn4TVMACFrCABaxPgCf1gachOy1hWkvutkrw9DIrW4C2zf/Wci7p5Xe2C1ECC1jAAhawgJX9qp9aCrm9AFxqs4v2goJPva/WDao9eTg9vCNdQgMLWMACFrC+Dax2s7G1RHK6tNiWrttm9bRZPP29qZJ8WoJvB9huhzOkzydgAQtYwAIWsGagpErJVFM5Bd52wbxtybUtNdKT0m8tLLi9MbSGQ2xLZWABC1jAAhawZhdAaypOa/madMmY3kA0NSB1e4NIbzE//fxbr6t1I9d0BxawgAUsYHWASv+e6Vf71gmW3iQhVcqlh0W0QU1tarKFMA2XkhBYwAIWsICVAS09peH2JOZ0KXv691vDRNqbLaSa/q2BselWhqY7sIAFLGABqwPUFKJUydMq2dL/bSFNT435lFJzCuT2OKcGrL5xsjOwgAUsYAHrN5SCW8BSJeL0Qk410z+lJEtdaK2pMtuStn0+mfwMLGABC1jA+oxS8XZzsrWw3ylo29ezHebQfsiRLk2nJWn78029TmABC1jAAhawdl/tt83LNGip13F6YaQu9G3TOd3M3n5+7alJreEtrSlowAIWsIAFLCXhrlmbXvajtTX99AROvc72wMdp6ZTe6v3WJhSt7eGmnw+wgAUsYAELWLsPpFXibIcH3GqWpgcyTm8Y6Sb+FpJtE7t9A2pBpiQEFrCABSxg7Zqrt5v525Lm1mP9FKhTGFqbTqRf77Y03rYM0ktcAwtYwAIWsIDVLXFSF076IUF7e69tSZp6H62HFunPYQtle1jDLQCBBSxgAQtY3wZWa+Gz1gmUKtWmr2NbKm2P77a0vT3MJA1e66HS9LgBC1jAAhawgDW7ME5/Ll2KpoBMD0BNTcpNHZcWrK3jn16auL2gpMnPwAIWsIAFrB0c0yZ1egpEeuPW9oU1bRanSpkUQO3J7+mfS0392R5PYAELWMACFrB2gDx9wqYHiG5//62mdntSemvBwGkTOzVwuPV5a7oDC1jAAhawzi7UdlO+vb3WaYmbLvnSJV0LtmlJnlrKeQtu6vxutzqABSxgAQtYSsJOU7490DB1Ym4vyPYCeK0lqtMDcNMLB6YeZqS28QIWsIAFLGABK/PVt71Y/7Yk3ZZi0/+/NZD1qS3vU8fx9P2mb6Ct5WQMawAWsIAFLGB1ToDbC6vdnjR8e6nlWwsJbm9I7WVipiV6a9hECmxgAQtYwAKWpvuulJteIO0lk7cPD9oL56UXSkwt15Ie4LltRbS3D2s9RAIWsIAFLGB9O1itqScpANtTbdKlQLop3d5cozVFpnWDmIKSfiiiJAQWsIAFLGBlLvDtiZQqCdrLvdwqZVPHa3rh3prUPS2t2gNA0w8jgAUsYAELWMDqlFLpkq81aTW1YekWnNaFnC59b0OeXnJ7eyN7UykILGABC1jAehKm1Ae6bcJOL+hTeNrbnLVLq+lxbW/ImjqftpO1by/5DCxgAQtYwAJWZqG2VKnS2oartVRwepmX1nFsD7icNtu351WqtNxOHgcWsIAFLGABa3bht06Q9iYF22b2tgRNNYuf2mQhfUNIPaRJtxbSDzOABSxgAQtYwMo+7k6Bli5JpyVLe+G8LVy3msNpyNKthunnk2qdAAtYwAIWsICV+SDSS9W2m7u3FqBLXWCpUq/VAmhvb9a6QaTANPkZWMACFrCAlf3qf2vj0/SA1napnC5Z0zCkth9LPWzYHvc0rG+CCFjAAhawgPUbSsPU1JxPOdHbzdj0MI3WgN7UwnvpAbNbqNLwGjgKLGABC1jAylzo6QXLWl/RUwMo08clvVDc6Y0jNcA1tZ1ba0Pe9HGbNu+VhMACFrCABawZLK3J0emF5tLN/PSFPT3htxdQeqG99hLJ7Sa45WWABSxgAQtYzzTb24/HUxdkqomeLjVSTe72lJwWDK2Su30DOwVeSQgsYAELWMDKfoVONYVT8LS2/0qXatuSKjXVJdV0nt4YWpPt26WipjuwgAUsYAGr04RMbZeVPlFvPWZvlXLp49qeMpQ+X9IPN1rL4CgJgQUsYAELWN0mfAq8T319rQti2uxODxPZDuRsLcvSPq7thQOBBSxgAQtYwNqBcHtqxfbv3z5B01ORntrU49YA0tRDoG0LpHVDARawgAUsYH170729jdT2dWxLpumFflpabsGeQpR6iLEtsaYlfHogbvphxK2pQ8ACFrCABay3grVtNqdO/BaYTy0cd/vCSw+zaDf928vttB+mAAtYwAIWsICVbb7f3rDz1jZVbWDTpeW01J1Clm6Wt45rCvDtQxFgAQtYwAKWpnsWjPRCbtuSqwVB+kJMbcOVmhqTaqKnJsOnSuwpPG8oDYEFLGABC1g3wDr9udZW6aclTXqL8u2yL79lgb3pDSz1+tKbhrTOXyUhsIAFLGABK3sipzd3SF+grW26WiVBalmV9IDR1AKIrRvctkROQ/qmAAtYwAIWsJ5out8CoN283j50aJWyKchbA0PTSySnHg6kWxip1w8sYAELWMAC1tmJcmvJ2NZyNq2SJwV5avOM1jCI6evZ/r30DW47TOVNzXZgAQtYwALWk832aVM1XSK2Nw9IL8PSOs63SpnUdl3Tkv6p5YxarxdYwAIWsIClJOyUgOmNVNMDTdNTUVJN3+1wghT0qdJregNKPVxIvR7LywALWMACFrB2YKXAS5WIqcfmqSZqalup9rCKdInbGr7SKsFuLegHLGABC1jAAtbZhXd6AU4v4PRAvzR06VIyDVDq82pPZWlvl5Y+L94cYAELWMAC1ic03dOlZgqw1hSO1s+lSsJ0M/rWlvWt4SXbG0HqYQuwgAUsYAELWNmv3umBf+0Tpr3VfRuO1LCHVBM+9e+kl6tJHf83AAUsYAELWMD6DaVh6vFweoDj7c0mbi+HkpoSs/3ct1vBt6cipY7Lm+ECFrCABSxg3YQq1RxOlYTbJmy6iZpuRqcv4NRxubVsTuohxbZ0TIMILGABC1jAUhJmm++ppmsK0HSJ1Cqlt6VUCqTUsI72MI3UphatGwGwgAUsYAELWGcXSGpp3tTyIFuIWiVhevmdpxbqSz2s2d5Q0p9X+2EDsIAFLGABS9P97sDB05I0Nel6+/rbpWCr5EgPwG1v+Z7eDi3VVH/jQn7AAhawgAWsm2C1l+ZNXfitKTPpZna71EwN7GxtFpJqUbQGzqZ+P7CABSxgAQtYuxLxqaZvapJragpMeoBjquRqD/dIA57a5OP097Y32AUWsIAFLGABq3PBpL6Spy/g6QWTOm7tkji9oF9684ZPfxiR3o4NWMACFrCApenebWbf2q5r2xxOL2G8BbL1/raP99OlYnrYRXv7sVd8OQEWsIAFLGBdLAGnJdr0xE5t/Z56PdMTdlo6pEvgVsmTXj7mFlyp8+eNzXdgAQtYwALWJzTbbzXLtydmGpL0QnRPDXhNDSO4vYxLeqDy9uc03YEFLGABC1jZEzo1CbQ16fWpx9Ktx/7pC3zbbH560vMWttT586ZmPLCABSxgAesTS8H0V+ynlrlJTx6eQtguVdtLLqdK9acmp6ffH7CABSxgAQtYnabvrQXb2kvZti74KZitkvfWANsUyKlJzlvggAUsYAELWMDagTUtJVtLELeaoO2/fwucKfCtEm9bGqan7KSBBRawgAUsYAEr07xslUCtgXq3S6NpCZQqbdOvezu1aAvy7RsmsIAFLGABC1gdmLalRuqrf/tCbjXfb00Sn95gUqVR6nPdvq7052hYA7CABSxgAasL1ukFlt7UoTWJddvkT5XA6Qu4NZWmtUFtanuuaanXupEDC1jAAhawvh2s9OPu9sJs0+Ztajuw1MOK9KTm1uP59iYU7c+r/RBA0x1YwAIWsIA1++qeBird1N2CkSqtUhdwa6nlKbAtaJ56aJMq3ZWEwAIWsIAFrM8qCadQTku/NDjbhwatLdPTA3LTN6bWQNVUSyB1QwUWsIAFLGABq1M6TL/St34uBeEWqu2N5PamELceEqSBuw2rkhBYwAIWsIDVgWR7Am+36Zo2j9MLu6VKu9T7uH2cTkGffs7pqTXfCBWwgAUsYAHrE5rwrZKtVeK1lnJOlz5pmKel/61tz9LDW6af37Y0fhNgwAIWsIAFrN8MVeordmsgaKs0m8Lx1BSgVIl2a4np9I0oXXICC1jAAhawNN278GwfO6e+yt9apmV6AUyBnH6urcnVKUhTpWB6ytL2BgMsYAELWMD69qb7tpTbLuNxewpNq5Sewp2+sbSHY6RK4nQJ2rohaLoDC1jAAhawZkC1Spj08IVUUzVVap0ep1PYUsc5NRwivWzP9gaYAjT1sAhYwAIWsIAFrF3pcmt7plNIUhC3HzqkLsT2wotb2NLbpT0FLbCABSxgAQtYmaZxqoRMl2zbCz/91T+9VXp7Ser0Bdt6+JC+caQfogALWMACFrCAlWnCtx+vb5u4qdKytdxKapOKdJN6e2Gmpy5t3296mSNLJAMLWMACFrCypeL0hHpqmZAWBNPS5qlhDFu4b8G+hap9/N8YYAELWMAC1m8qIbdN9S0QKQin7ye9NXp6qd9WSdk6P1Il4fYhk2ENwAIWsIAFrF3pt92sofVVOz2gdXrCT993G9Rpab+dZJ5aCrk1UHcK2vTfBxawgAUsYAFr12zeNtfbvycFwO2FBlMPP7bbcbWa9+lJ2a0Bz7duKMACFrCABaxvAatVcrVP8Fsbgaab4+3hF6nj3/4cWtvJTZv87c8BWMACFrCABazOhpjthenSj+XTS/amm9OpUq496TfVhN/+++mHGMACFrCABSxgdcBKl3Spn99e0OmliFPbVt2arHtr+aDW8d8+hDA1B1jAAhawgNVpwk5P0PRA0VTTvv16pyVgamPX0wv/VqnTGqC5fSjyVGkKLGABC1jA+hawUlNzWo+fpyVt6n9vLWSYKqXTgKdKyPTGsdvPZwtYqnkPLGABC1jAejtYIvKdAZaIAEtEBFgiAiwREWCJiABLRIAlIgIsERFgiQiwRESAJSICLBEBlogIsEREgCUiwBIRAZaICLBEBFgiIsASEQGWiABLRARYIiLAEhFgiYgAS0QEWCICLBERYIkIsBwCEQGWiAiwRARYIiLAEhEBlogAS0QEWCIiwBIRYImIAEtEBFgiAiwREWCJiABLRN6YfwHiWmwPeTf+OAAAAABJRU5ErkJggg==";

		public static string SrcBase64Qrode = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAAB4CAYAAAAE9le0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAadSURBVHgB7Zw5UBxHFIZ7Vc50lEMdsaTUpSMW5VSCmCOwEo6YIwWWkCvmqrLsKiDmioGU0ymQA5ldQMx6vi6/ra5lJWBnVzyZ/6sabe9Mz0z3+9973T07ohD+o1QqNWUfQ9n2S7b9HMT3YiPbvhQKhT/4UuCfTAyEGA7irihlWzETpVjIxPicffk9iLsGUX5FkPWs0BSEB9YRpBSEF/6WIL4oPQjCFRLEGRLEGRLEGRLEGRLEGRLEGRLEGRLEGRLEGRLEGRLEGRLEGRLEGRLEGRLEGRLEGRLEGT+FBvPu3bvQSHZ2dsplfo1+//59aBSFQiFsb2+HRqIIcYYEcYYEcYYEcYYEcYYEcYYEcUbD1yHXka4jqlHPdcx164hGr2NugiLEGRLEGRLEGRLEGRLEGRLEGRLEGXe+Dmn07yUprDO+5/1qQRHiDAniDAniDAniDAniDAniDAniDP1pDV/oT2t4Q4I4Q4I4416925v3N3W923sPkSDOkCDOkCDOkCDOkCDOkCDOuFfv9uo3dXFrJIgzJIgz7nwMqSc8a/rWmOThWdV1KEKcIUGcIUGc8b96t/cmY8R1Y8y32qPfQ+4hEsQZEsQZEsQZEsQZEsQZEsQZerfXF3q31xsSxBkSxBkSxBkSxBkSxBkSxBkSxBkSxBkSxBkSxBkSxBkSxBkSxBkSxBl1E2RiYiIMDw/H8vHxcSxvbGx8tf7MzEzV4+zjWufn56HecM/V1dXytWkn+w4PD8Pu7m5YXFyseh4/GaVbtX3psTzkelGuu7s7dmRlZSVsbm6WhWAfHYempqaq52KIT58+XTmOUTj/7du3Vc89OTkJN+XRo0fh8ePHsYyxaBMvu3Ff4KU52kEdROH4q1ev4r3tnGKxeOWeHOe8Srj2/Px8vEatNOTNRRODTysDhujr6wsXFxfxO594a0dHRxQzpb+/v1x+9uxZFB1M8JtAXTM+53MP7o+Bnz59GtbW1qIRMeDLly/jdRHm+fPnUUw26rKPdiLckydPYtlEM6hDf8wBaqXugtBpOkbDKj3l9evXseFEFpCerA71P3z4cOV6RF4KxrpplGBQwNPn5ubiuQ8fPgzNzc1haGioLKy1B0iXbLxSOjU1Faanp8PCwkKYnJyMYprA7KNtiI64PT09YW9vLzpPHuouyOzsbPzEuBgAb6IjBoLRKSKH4wjChvH4jrHolEUWXmeGBQx5Wyw6SIEmDMYDPJ328J16lNlXLdWlqQwxOMfahpPkjQ6o+yzLUkt7e3vsCGNCS0tL2asxhg3+b968iUbq7e2Nx8nLeCQiUqYeHU4FrQXuCUSkOYS1EyNairK6OISdQ32i2tIm7aKtNjGw86hHnbwDe90jZHl5OXoOXk/IE8o09uDg4Eo40zGMRDqgTltbW9n4nMuAiqjUQ6hasfQzMjISv5NiDO6fzvYwuA38g4OD5Yi3GRnHcCTahBj0L521DQwMhPHx8VAruQSxPMxsxVKO5WXzQIxMhxk/gOPkaCsjUmdnZzklWCTxnQghV5PG8sIAzrXHxsZiO4lM2sUnTrC+vl4eJ9hnnm+pk7ZxXppKwVIf7UUYoikPuQTBoHhxSuX3tC5eZykAbMzgWLVppIGYeaaSRKc5CLM3rkWaRBCMiEMdHR2V65pzEQkIYY5jEY7xt7a2rtyH/5tiqa5W6pKy8ChysQ2KNNjKeFKaEuggxxDCOgxdXV3xk86beNa5PGLY+bbRTovW9H4GEUA02eCOcEzLwRZ/lY5If0dHR0M9qIsgdNQGPfI1jbYyEZEKUs2D6LgJQ6TQYQSrnOuT6m6bEkiZOAypj5RFBPB5eXkZj3MfxgrayxhDmvz48WM0MqSzKBsrENWO2yBerycLNQuCkS1/YiTL/YS/NZay5VrKiFZpZFu3GGZwmxEZGM4ecdwGzrN1REoakelqHGFoK0ZPZ3d2X1tILi0tRREQOG33nS0M7REHpBGQrswry3QaQ9hCjMZXG4fs+ikYlnMrV/TXgQOYgSnjFLbuAYy6v78fyy9evAinp6dxS2eENrPiGulC9ezsLM6y0nqVDndban7ZGkPe1jhmFAZWOoww3P4mK++8Ha0Ej2aKygKWceJrIBgOR6ql/UQEqdjWHDaVBsam1tbWkIOS3n73hd5+94YEcYYEcYYEcYYEcYYEcYYEcYYEcQaC/BOEGxDkryC8sIEgxSA8wCOsLw+yJ5QbQaLcNYhRzLT4s1DeUyp9zj5+y7am8OPyoz0oZfxmyECM+Fz/X0HgsoSqbxPSAAAAAElFTkSuQmCC";

		public static string supperPassword = "cjMn";

		public static string UpdateUrl = "";

		public static string UpdateLocalFile = "";

		public static int PantInterval = 30;

		public static DictObject dictObjects = null;

		private static POINT point;

		public static void CreateImage(ref Panel pnl, Color _color)
		{
			Bitmap bitmap = new Bitmap(pnl.Width, pnl.Height);
			Graphics graphics = Graphics.FromImage(bitmap);
			Rectangle rect = new Rectangle(0, 0, pnl.Width, pnl.Height);
			SolidBrush brush = new SolidBrush(_color);
			graphics.FillRectangle(brush, rect);
			pnl.BackgroundImage = bitmap;
		}

		public static void CreateImageLable(ref Label pnl, Color _color)
		{
			Bitmap bitmap = new Bitmap(pnl.Width, pnl.Height);
			Graphics graphics = Graphics.FromImage(bitmap);
			Rectangle rect = new Rectangle(0, 0, pnl.Width, pnl.Height);
			SolidBrush brush = new SolidBrush(_color);
			graphics.FillRectangle(brush, rect);
			pnl.BackgroundImage = bitmap;
		}

		public static void CreateImagePictureBox(ref PictureBox pnl, Color _color)
		{
			Bitmap bitmap = new Bitmap(pnl.Width, pnl.Height);
			Graphics graphics = Graphics.FromImage(bitmap);
			Rectangle rect = new Rectangle(0, 0, pnl.Width, pnl.Height);
			SolidBrush brush = new SolidBrush(_color);
			graphics.FillRectangle(brush, rect);
			pnl.BackgroundImage = bitmap;
		}

		public static string GetValue(string str, string s, string e)
		{
			return new Regex("(?<=(" + s + "))[.\\s\\S]*?(?=(" + e + "))", RegexOptions.Multiline | RegexOptions.Singleline).Match(str).Value;
		}

		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern int GetDC(int hwnd);

		[DllImport("gdi32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern int GetPixel(int hdc, int x, int y);

		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern int ReleaseDC(int hwnd, int hdc);

		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern int WindowFromPoint(int x, int y);

		[DllImport("user32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern int ScreenToClient(int hwnd, ref POINT lppoint);

		public static Color GetPixelColor(int x, int y)
		{
			int hwnd = WindowFromPoint(x, y);
			int dC = GetDC(hwnd);
			ScreenToClient(hwnd, ref point);
			return Color.FromArgb(GetPixel(dC, x, y));
		}
	}
}
