using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace SelfExamClient.Properties
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (resourceMan == null)
				{
					resourceMan = new ResourceManager("SelfExamClient.Properties.Resources", typeof(Resources).Assembly);
				}
				return resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return resourceCulture;
			}
			set
			{
				resourceCulture = value;
			}
		}

		internal static Bitmap close => (Bitmap)ResourceManager.GetObject("close", resourceCulture);

		internal static Bitmap CloseButton => (Bitmap)ResourceManager.GetObject("CloseButton", resourceCulture);

		internal static Bitmap logoah => (Bitmap)ResourceManager.GetObject("logoah", resourceCulture);

		internal static Bitmap logoks => (Bitmap)ResourceManager.GetObject("logoks", resourceCulture);

		internal static Bitmap Right => (Bitmap)ResourceManager.GetObject("Right", resourceCulture);

		internal static Bitmap Split => (Bitmap)ResourceManager.GetObject("Split", resourceCulture);

		internal static Bitmap Warning => (Bitmap)ResourceManager.GetObject("Warning", resourceCulture);

		internal Resources()
		{
		}
	}
}
