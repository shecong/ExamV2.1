using System;
using System.Collections.Generic;
using System.IO;
using CefSharp;

namespace SelfExamClient
{
	public class CefSharpSchemeHandlerFactory : ISchemeHandlerFactory
	{
		public const string SchemeName = "custom";

		public const string SchemeNameTest = "test";

		private static readonly IDictionary<string, string> ResourceDictionary;

		static CefSharpSchemeHandlerFactory()
		{
			ResourceDictionary = new Dictionary<string, string>();
		}

		public IResourceHandler Create(IBrowser browser, IFrame frame, string schemeName, IRequest request)
		{
			Uri uri = new Uri(request.Url);
			string absolutePath = uri.AbsolutePath;
			if (absolutePath.EndsWith("CefSharp.Core.xml", StringComparison.OrdinalIgnoreCase))
			{
				ResourceHandler.GetMimeType(".xml");
				return ResourceHandler.FromFilePath("CefSharp.Core.xml");
			}
			if (uri.Host == "cefsharp.com" && schemeName == "https" && (string.Equals(absolutePath, "/PostDataTest.html", StringComparison.OrdinalIgnoreCase) || string.Equals(absolutePath, "/PostDataAjaxTest.html", StringComparison.OrdinalIgnoreCase)))
			{
				return null;
			}
			if (string.Equals(absolutePath, "/EmptyResponseFilterTest.html", StringComparison.OrdinalIgnoreCase))
			{
				return ResourceHandler.FromString("", ".html");
			}
			if (ResourceDictionary.TryGetValue(absolutePath, out var value) && !string.IsNullOrEmpty(value))
			{
				string extension = Path.GetExtension(absolutePath);
				return ResourceHandler.FromString(value, null, includePreamble: true, ResourceHandler.GetMimeType(extension));
			}
			return null;
		}
	}
}
