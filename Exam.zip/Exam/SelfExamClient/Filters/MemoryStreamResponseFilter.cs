using System;
using System.IO;
using CefSharp;

namespace SelfExamClient.Filters
{
	public class MemoryStreamResponseFilter : IResponseFilter, IDisposable
	{
		private MemoryStream memoryStream;

		public byte[] Data => memoryStream.ToArray();

		bool IResponseFilter.InitFilter()
		{
			memoryStream = new MemoryStream();
			return true;
		}

		FilterStatus IResponseFilter.Filter(Stream dataIn, out long dataInRead, Stream dataOut, out long dataOutWritten)
		{
			if (dataIn == null)
			{
				dataInRead = 0L;
				dataOutWritten = 0L;
				return FilterStatus.Done;
			}
			dataInRead = dataIn.Length;
			dataOutWritten = Math.Min(dataInRead, dataOut.Length);
			dataIn.CopyTo(dataOut);
			dataIn.Position = 0L;
			dataIn.CopyTo(memoryStream);
			return FilterStatus.Done;
		}

		void IDisposable.Dispose()
		{
			memoryStream.Dispose();
			memoryStream = null;
		}
	}
}
