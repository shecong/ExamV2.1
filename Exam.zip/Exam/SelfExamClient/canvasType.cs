namespace SelfExamClient
{
	public enum canvasType
	{
		GATEWAY,
		NODE,
		DONGLE,
		P1,
		T7E_TS,
		T7E_HFHH
	}
}
